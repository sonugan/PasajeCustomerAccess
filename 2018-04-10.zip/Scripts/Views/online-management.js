﻿$(function () {
    $("table").footable();
});