﻿CrateAppAngular();
GetBaseAddress();
var scope;

myApp.controller('CtrlFaqs', ['$scope', '$http', function ($scope, $http) {
    scope = $scope;

    //TRAER ITEM/S
    $scope.ObtenerFaqs = function ObtenerFaqs() {
        $scope.rowCollection = [];
        $scope.displayed = [].concat($scope.rowCollection);
        $scope.isLoading = true;
        $http.get(BaseAddress + "Faqs/GetFaqs").success(function (data) {
            $scope.rowCollection = [];
            $scope.displayed = [].concat($scope.rowCollection);

            $scope.rowCollection = data;
            $scope.displayed = [].concat($scope.rowCollection);
            $scope.isLoading = false;


        }).error(function () {
            $scope.isLoading = false;
            alert('Ha ocurrido un error');
        });
    }

    $scope.ObtenerFaqs();

    //ELIMINAR ITEM
    $scope.removeItem = function removeItem() {
        var Bajastr = "";

        $.each($scope.displayed, function (i, value) {
            if (value.isSelected) {
                Bajastr += value.Id + ",";
            }
        });
        if (Bajastr != "") {
            $("#confirmModal").modal("show");
        }
    }

    //CONFIRMAR BAJA
    $("#BtnConfirmaBaja").click(function () {
        $("#BtnConfirmaBaja").attr('disabled', 'disabled');
        $("#BtnCancelar").attr("disabled", "disabled");
        $("#Cargando").removeClass("hidden");
        var Bajastr = "";

        $.each($scope.displayed, function (i, value) {
            if (value.isSelected) {
                Bajastr += value.Id + ",";
            }
        });
        $.ajax({
            url: BaseAddress + 'Faqs/RemoveFaqs/',
            type: 'POST',
            data: { id: Bajastr },
            cache: false
        }).success(function (result) {
            $("#confirmModal").modal("hide");
            $("#BtnConfirmaBaja").removeAttr("disabled");
            $("#BtnCancelar").removeAttr("disabled");
            $("#Cargando").addClass("hidden");
            $scope.ObtenerFaqs();
        }).error(function (ex) {
            $scope.isLoading = false;
            $("#BtnConfirmaBaja").removeAttr("disabled");
            $("#BtnCancelar").removeAttr("disabled");
            $("#Cargando").addClass("hidden");
            alert('Ha ocurrido un error');
        })
    })

    $("#BtnCancelar").click(function () {
        $("#confirmModal").modal("hide");
    })

    //AGREGAR
    $scope.addItem = function addItem() {
        $("#MensajeSalidaAlta").addClass("hidden");
        $("#addFaqsModal").modal("show");
        $('#Order').val('1');
        $("#Title").val("");
        $("#Description").val("");
        $("#titulo").text("Nuevo");
    }

    //CANCELAR
    $("#BtnCancelarAlta").click(function () {
        $("#addFaqsModal").modal("hide");
        $("#Id").val(0);
        $("#Title").val("");
        $("#Description").val("");
    })

    //MODIFICAR ITEM
    $scope.editItem = function editItem() {
        var selectedItems = 0;
        var item;
        $.each($scope.displayed, function (i, value) {
            if (value.isSelected) {
                selectedItems = selectedItems + 1;
                item = value;
            }
        });
        if (selectedItems == 1) {
            $("#MensajeSalidaAlta").addClass("hidden");
            $("#addFaqsModal").modal("show");
            $("#titulo").text("Editar");
            $("#Id").val(item.Id);
            $("#Title").val(item.Title);
            $("#Description").val(item.Description);
            $('#Order').val(item.Order);
        }
    }
    //BOTON EDITAR/ELIMINAR -- CONTROL QUE HABILITA EL/LOS BOTON/ES
    $scope.controlButton = function controlButton(action) {
        var selectedItems = 0;
        var item;
        $.each($scope.displayed, function (i, value) {
            if (value.isSelected) {
                selectedItems = selectedItems + 1;
                item = value;
            }
        });
        if (selectedItems == 1 && action == 'edit') {
            return false;
        }
        else if (selectedItems >= 1 && action == 'remove') {
            return false;
        }
        return true;
    }
    //ICONO SORT
    $scope.sort = {
        active: '',
        descending: undefined
    }

    $scope.changeSorting = function (column) {

        var sort = $scope.sort;

        if (sort.active == column) {
            sort.descending = !sort.descending;
        }
        else {
            sort.active = column;
            sort.descending = false;
        }
    };

    $scope.getIcon = function (column) {

        var sort = $scope.sort;

        if (sort.active == column) {
            return sort.descending
              ? 'fa-sort-asc'
              : 'fa-sort-desc';
        }

        return 'fa-sort';
    }
    //Order
    $scope.options = [];

    $scope.selectedItem = $scope.options[1];

}]).directive('stRatio', function () {
    return {
        link: function (scope, element, attr) {
            var ratio = +(attr.stRatio);
            element.css('width', ratio + '%');
        }
    };
}).directive('csSelect', function () {
    return {
        require: '^stTable',
        template: '<input type="checkbox"/>',
        scope: {
            row: '=csSelect'
        },
        link: function (scope, element, attr, ctrl) {
            element.bind('change', function (evt) {
                scope.$apply(function () {
                    ctrl.select(scope.row, 'multiple');
                });
            });

            scope.$watch('row.isSelected', function (newValue, oldValue) {
                if (newValue === true) {
                    element.parent().addClass('st-selected');
                } else {
                    element.parent().removeClass('st-selected');
                }
            });
        }
    };
}).directive('pageSelect', function () {
    return {
        restrict: 'E',
        template: '<input type="text" class="select-page" ng-model="inputPage" ng-change="selectPage(inputPage)">',
        link: function (scope, element, attrs) {
            scope.$watch('currentPage', function (c) {
                scope.inputPage = c;
            });
        }
    }
})

//Busqueda
.directive('searchWatchModel', function () {
    return {
        require: '^stTable',
        scope: {
            searchWatchModel: '='
        },
        link: function (scope, ele, attr, ctrl) {
            var table = ctrl;

            scope.$watch('searchWatchModel', function (val) {
                ctrl.search(val);
            });
        }
    };
});

function OnSuccess(response) {
    if (response.success == true) {
        $("#addFaqsModal").modal("hide");
        scope.ObtenerFaqs();
        $("#Id").val(0);
        $("#btnAceptar").removeAttr("disabled");
        $("#BtnCancelarAlta").removeAttr("disabled");
        $("#CargandoAlta").addClass("hidden");
    }
    else {
        ModelFailure(response);
    }
}

function ModelFailure(response) {
    var msgmodel;
    $("#MensajeSalidaAlta").removeClass("hidden");
    $("#lblmensajealta ul").empty();

    msgmodel = "";
    $.each(JSON.parse(response), function (i, value) {
        $.each(value.Errors, function (e, val) {
            msgmodel += "<li>" + val.ErrorMessage + "</li>";
        });
    });
    $("#lblmensajealta ul").append(msgmodel);
    $("#btnAceptar").removeAttr("disabled");
    $("#BtnCancelarAlta").removeAttr("disabled");
    $("#CargandoAlta").addClass("hidden");
}

function OnFailure(response) {
    var msgEx;
    $("#MensajeSalidaAlta").removeClass("hidden");
    $("#lblmensajealta ul").empty();
    msgEx = "";
    msgEx += "<li>" + "Ha ocurrido un error" + "</li>";
    $("#lblmensajealta ul").append(msgEx);
    $("#btnAceptar").removeAttr("disabled");
    $("#BtnCancelarAlta").removeAttr("disabled");
    $("#CargandoAlta").addClass("hidden");
}

//manejo de botones
//aceptar y modificar
$(function() {
    $("#btnAceptar").on("click", function () {
        $("#btnAceptar").attr('disabled', 'disabled');
        $("#BtnCancelarAlta").attr("disabled", "disabled");
        $("#CargandoAlta").removeClass("hidden");
    })
});