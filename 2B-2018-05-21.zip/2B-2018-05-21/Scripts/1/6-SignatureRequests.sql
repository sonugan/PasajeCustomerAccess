CREATE TABLE [dbo].[SignatureRequestsEncrypt](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[ProcedureNumber] [bigint] NULL,
	[CreationDate] [datetime2](7) NOT NULL,
	[PolicyNumber] [varchar](15) NOT NULL,
	[ClientId] [varchar](15) NOT NULL,
	[DocumentType] [int] NOT NULL,
	[DocumentId] [varchar](100) NULL,
	[DocumentName] [varchar](255) NULL,
	[DestinationContent] [varchar](100) NULL,
	[SignatureOnlineStatus] [varchar](100) NOT NULL,
	[SignatureOnlineDate] [datetime2](7) NULL,
	[SignatureOnlineUser] [varchar](100) NULL,
	[SignatureInPersonStatus] [varchar](100) NULL,
	[SignatureInPersonDate] [datetime2](7) NULL,
	[SignatureInPersonUser] [varchar](100) NULL,
	[AddressIP] [varbinary](max) NULL,
	[DeviceName] [varbinary](max) NULL,
	[PolicyStatus] [varchar](100) NULL,
	[UpdateDate] [datetime2](7) NOT NULL,
	[Observations] [varchar](100) NULL,
	[PolicyStatusDate] [datetime2](7) NULL,
 CONSTRAINT [PK_SignatureRequestsEncrypt] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[SignatureRequestsEncrypt] ADD  CONSTRAINT [DF_SignatureRequestsEncrypt_UpdateDate]  DEFAULT (getdate()) FOR [UpdateDate]
GO
ALTER TABLE [dbo].[SignatureRequestsEncrypt]  WITH CHECK ADD  CONSTRAINT [FK_SignatureRequestsEncrypt_TransactionRequests] FOREIGN KEY([ProcedureNumber])
REFERENCES [dbo].[TransactionRequests] ([Id])
GO
ALTER TABLE [dbo].[SignatureRequestsEncrypt] CHECK CONSTRAINT [FK_SignatureRequestsEncrypt_TransactionRequests]
GO

INSERT INTO [SignatureRequestsEncrypt] (
	[ProcedureNumber],
	[CreationDate],
	[PolicyNumber],
	[ClientId],
	[DocumentType],
	[DocumentId],
	[DocumentName],
	[DestinationContent],
	[SignatureOnlineStatus],
	[SignatureOnlineDate],
	[SignatureOnlineUser],
	[SignatureInPersonStatus],
	[SignatureInPersonDate],
	[SignatureInPersonUser],
	[AddressIP],
	[DeviceName],
	[PolicyStatus],
	[UpdateDate],
	[Observations],
	[PolicyStatusDate]
  )
  SELECT
	[ProcedureNumber],
	[CreationDate],
	[PolicyNumber],
	[ClientId],
	[DocumentType],
	[DocumentId],
	[DocumentName],
	[DestinationContent],
	[SignatureOnlineStatus],
	[SignatureOnlineDate],
	[SignatureOnlineUser],
	[SignatureInPersonStatus],
	[SignatureInPersonDate],
	[SignatureInPersonUser],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [AddressIP] ),
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [DeviceName] ),
	[PolicyStatus],
	[UpdateDate],
	[Observations],
	[PolicyStatusDate]
  FROM SignatureRequests

GO

DROP TABLE SignatureRequests  
  
GO
CREATE VIEW [dbo].[SignatureRequests] AS
SELECT 
	[Id],
	[ProcedureNumber],
	[CreationDate],
	[PolicyNumber],
	[ClientId],
	[DocumentType],
	[DocumentId],
	[DocumentName],
	[DestinationContent],
	[SignatureOnlineStatus],
	[SignatureOnlineDate],
	[SignatureOnlineUser],
	[SignatureInPersonStatus],
	[SignatureInPersonDate],
	[SignatureInPersonUser],
	CAST(DECRYPTBYKEY( [AddressIP] ) AS varchar(100)) [AddressIP],
	CAST(DECRYPTBYKEY( [DeviceName] ) AS varchar(100)) [DeviceName],
	[PolicyStatus],
	[UpdateDate],
	[Observations],
	[PolicyStatusDate]
FROM SignatureRequestsEncrypt
GO
CREATE TRIGGER [dbo].[SignatureRequestsTg] on [dbo].[SignatureRequests]
INSTEAD OF INSERT
AS
BEGIN
  INSERT INTO [SignatureRequestsEncrypt] (
	[ProcedureNumber],
	[CreationDate],
	[PolicyNumber],
	[ClientId],
	[DocumentType],
	[DocumentId],
	[DocumentName],
	[DestinationContent],
	[SignatureOnlineStatus],
	[SignatureOnlineDate],
	[SignatureOnlineUser],
	[SignatureInPersonStatus],
	[SignatureInPersonDate],
	[SignatureInPersonUser],
	[AddressIP],
	[DeviceName],
	[PolicyStatus],
	[UpdateDate],
	[Observations],
	[PolicyStatusDate]
  )
  SELECT
	[ProcedureNumber],
	[CreationDate],
	[PolicyNumber],
	[ClientId],
	[DocumentType],
	[DocumentId],
	[DocumentName],
	[DestinationContent],
	[SignatureOnlineStatus],
	[SignatureOnlineDate],
	[SignatureOnlineUser],
	[SignatureInPersonStatus],
	[SignatureInPersonDate],
	[SignatureInPersonUser],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [AddressIP] ),
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [DeviceName] ),
	[PolicyStatus],
	[UpdateDate],
	[Observations],
	[PolicyStatusDate]
  FROM inserted
END;
GO
