---ChangePhoneRequests
CREATE TABLE [dbo].[ChangePhoneRequestsEncrypt](
	[Id] [bigint] NOT NULL,
	[Number] [varbinary](max) NOT NULL,
	[CountryCodeNumber] [int] NOT NULL,
	[ProvinceCodeNumber] [int] NOT NULL,
	[InternalNumber] [int] NULL,
 CONSTRAINT [PK_ChangePhoneRequestsEncrypt] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

INSERT INTO [ChangePhoneRequestsEncrypt] (
	[Id],
	[Number],
	CountryCodeNumber,
	ProvinceCodeNumber,
	InternalNumber
  )
  SELECT
	[Id],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), CONVERT(varbinary, [Number]) ),
	CountryCodeNumber,
	ProvinceCodeNumber,
	InternalNumber
FROM ChangePhoneRequests

GO

DROP TABLE ChangePhoneRequestsEncrypt

GO

CREATE VIEW [dbo].[ChangePhoneRequests] AS
SELECT 
	[Id],
	CAST(DECRYPTBYKEY( [Number] ) AS bigint) [Number],
	CountryCodeNumber,
	ProvinceCodeNumber,
	InternalNumber
FROM ChangePhoneRequestsEncrypt

GO

CREATE TRIGGER [dbo].[ChangePhoneRequestsTg] on [dbo].[ChangePhoneRequests]
INSTEAD OF INSERT
AS
BEGIN
  INSERT INTO [ChangePhoneRequestsEncrypt] (
	[Id],
	[Number],
	CountryCodeNumber,
	ProvinceCodeNumber,
	InternalNumber
  )
  SELECT
	[Id],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), CONVERT(varbinary, [Number]) ),
	CountryCodeNumber,
	ProvinceCodeNumber,
	InternalNumber
  FROM inserted
END;