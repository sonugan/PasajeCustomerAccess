---dbo.ChangeAddressRequests.View

CREATE TABLE [dbo].[ChangeAddressRequestsEncrypt](
	[Id] [bigint] NOT NULL,
	[ZipCode] [varchar](8) NULL,
	[Locality] [varchar](30) NULL,
	[IdProvince] [int] NOT NULL,
	[Address] [varbinary](max) NOT NULL,
	[Floor] [int] NULL,
	[Apartment] [varchar](10) NULL,
 CONSTRAINT [PK_ChangeAddressRequestsEncrypt] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[ChangeAddressRequestsEncrypt]  WITH CHECK ADD  CONSTRAINT [FK_CARequestsEncrypt_Provinces] FOREIGN KEY([IdProvince])
REFERENCES [dbo].[Provinces] ([Id])
GO
ALTER TABLE [dbo].[ChangeAddressRequestsEncrypt] CHECK CONSTRAINT [FK_CARequestsEncrypt_Provinces]
GO

OPEN SYMMETRIC KEY CustomerAccessDataKey DECRYPTION BY CERTIFICATE SSISCertificate
INSERT INTO [ChangeAddressRequestsEncrypt] (
	[Id],
	[ZipCode],
	[Locality],
	[IdProvince],
	[Address],
	[Floor],
	[Apartment]
  )
  SELECT
	[Id],
	[ZipCode],
	[Locality],
	[IdProvince],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [Address] ),
	[Floor],
	[Apartment]
  FROM ChangeAddressRequests;
IF((SELECT SUM(ISNULL(status, 0)) FROM sys.openkeys) > 0) CLOSE SYMMETRIC KEY CustomerAccessDataKey

GO

DROP TABLE ChangeAddressRequests

GO

CREATE VIEW [dbo].[ChangeAddressRequests] AS
SELECT 
	[Id],
	[ZipCode],
	[Locality],
	[IdProvince],
	CAST(DECRYPTBYKEY( [Address] ) AS varchar(50)) [Address],
	[Floor],
	[Apartment]
FROM ChangeAddressRequestsEncrypt

GO

CREATE TRIGGER [dbo].[ChangeAddressRequestsTg] on [dbo].[ChangeAddressRequests]
INSTEAD OF INSERT
AS
BEGIN
  INSERT INTO [ChangeAddressRequestsEncrypt] (
	[Id],
	[ZipCode],
	[Locality],
	[IdProvince],
	[Address],
	[Floor],
	[Apartment]
  )
  SELECT
	[Id],
	[ZipCode],
	[Locality],
	[IdProvince],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [Address] ),
	[Floor],
	[Apartment]
  FROM inserted
END;
GO
