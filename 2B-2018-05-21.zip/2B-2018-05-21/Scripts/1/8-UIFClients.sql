---UIFClients

CREATE TABLE [dbo].[UIFClientsEncrypt](
	[SCLIENT] [char](14) NOT NULL,
	[SFIRSTNAME] [varbinary](max) NULL,
	[SMIDDLENAME] [varbinary](max) NULL,
	[SLASTNAME] [varbinary](max) NULL,
	[SSEXCLIEN] [int] NULL,
	[TYPE_DOC_FIS] [int] NULL,
	[DOCUMENT_FIS] [varbinary](max) NULL,
	[TYPE_DOC_JUR] [int] NULL,
	[DOCUMENT_JUR] [varbinary](max) NULL,
	[NACIONALTY] [int] NULL,
	[CIVILSTA] [int] NULL,
	[STREET] [varbinary](max) NULL,
	[LOCAT] [int] NULL,
	[PROVINCE] [int] NULL,
	[COUNTRY] [int] NULL,
	[PHONE] [varbinary](max) NULL,
	[EMAIL] [varbinary](max) NULL,
	[ACTIVITY] [int] NULL,
	[SPECIALITY] [int] NULL,
	[ZIPCODE] [char](10) NULL,
	[DATE_REGISTER_INSCR] [varchar](1) NULL,
	[DATE_CONST] [varchar](1) NULL,
	[DBIRTHDAT] [datetime] NULL,
	[SBORNPLACE] [char](19) NULL,
	[DBIRTHDAT_SBORNPLACE] [varchar](31) NULL,
	[FATCA] [varchar](2) NULL,
	[SRAZONSOCIAL] [varbinary](max) NULL,
 CONSTRAINT [PK_UIFClientsImport] PRIMARY KEY CLUSTERED 
(
	[SCLIENT] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[UIFClientsImport](
	[SCLIENT] [char](14) NOT NULL,
	[SFIRSTNAME] [varbinary](max) NULL,
	[SMIDDLENAME] [varbinary](max) NULL,
	[SLASTNAME] [varbinary](max) NULL,
	[SSEXCLIEN] [int] NULL,
	[TYPE_DOC_FIS] [int] NULL,
	[DOCUMENT_FIS] [varbinary](max) NULL,
	[TYPE_DOC_JUR] [int] NULL,
	[DOCUMENT_JUR] [varbinary](max) NULL,
	[NACIONALTY] [int] NULL,
	[CIVILSTA] [int] NULL,
	[STREET] [varbinary](max) NULL,
	[LOCAT] [int] NULL,
	[PROVINCE] [int] NULL,
	[COUNTRY] [int] NULL,
	[PHONE] [varbinary](max) NULL,
	[EMAIL] [varbinary](max) NULL,
	[ACTIVITY] [int] NULL,
	[SPECIALITY] [int] NULL,
	[ZIPCODE] [char](10) NULL,
	[DATE_REGISTER_INSCR] [varchar](1) NULL,
	[DATE_CONST] [varchar](1) NULL,
	[DBIRTHDAT] [datetime] NULL,
	[SBORNPLACE] [char](19) NULL,
	[DBIRTHDAT_SBORNPLACE] [varchar](31) NULL,
	[FATCA] [varchar](2) NULL,
	[SRAZONSOCIAL] [varbinary](max) NULL,
 CONSTRAINT [PK_UIFClientsEncrypt] PRIMARY KEY CLUSTERED 
(
	[SCLIENT] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

CREATE VIEW [dbo].[UIFClientsInsert] AS
SELECT 
	[SCLIENT],
	CAST(DECRYPTBYKEY( [SFIRSTNAME] ) AS char(19)) [SFIRSTNAME],
	CAST(DECRYPTBYKEY( [SMIDDLENAME] ) AS char(19)) [SMIDDLENAME],
	CAST(DECRYPTBYKEY( [SLASTNAME] ) AS char(19)) [SLASTNAME],
	[SSEXCLIEN],
	[TYPE_DOC_FIS],
	CAST(DECRYPTBYKEY( [DOCUMENT_FIS] ) AS char(50)) [DOCUMENT_FIS],
	[TYPE_DOC_JUR],
	CAST(DECRYPTBYKEY( [DOCUMENT_JUR] ) AS char(50)) [DOCUMENT_JUR],
	[NACIONALTY],
	[CIVILSTA],
	CAST(DECRYPTBYKEY( [STREET] ) AS varchar(121)) [STREET],
	[LOCAT],
	[PROVINCE],
	[COUNTRY],
	CAST(DECRYPTBYKEY( [PHONE] ) AS char(11)) [PHONE],
	CAST(DECRYPTBYKEY( [EMAIL] ) AS char(60)) [EMAIL],
	[ACTIVITY],
	[SPECIALITY],
	[ZIPCODE],
	[DATE_REGISTER_INSCR],
	[DATE_CONST],
	[DBIRTHDAT],
	[SBORNPLACE],
	[DBIRTHDAT_SBORNPLACE],
	[FATCA],	
	CAST(DECRYPTBYKEY( [SRAZONSOCIAL] ) AS varchar(60)) [SRAZONSOCIAL]
FROM UIFClientsImport

GO

CREATE TRIGGER [dbo].[UIFClientsInsertTg] on [dbo].[UIFClientsInsert]
INSTEAD OF INSERT
AS
BEGIN
  INSERT INTO [UIFClientsImport] (
	[SCLIENT],
	[SFIRSTNAME],
	[SMIDDLENAME],
	[SLASTNAME],
	[SSEXCLIEN],
	[TYPE_DOC_FIS],
	[DOCUMENT_FIS],
	[TYPE_DOC_JUR],
	[DOCUMENT_JUR],
	[NACIONALTY],
	[CIVILSTA],
	[STREET],
	[LOCAT],
	[PROVINCE],
	[COUNTRY],
	[PHONE],
	[EMAIL],
	[ACTIVITY],
	[SPECIALITY],
	[ZIPCODE],
	[DATE_REGISTER_INSCR],
	[DATE_CONST],
	[DBIRTHDAT],
	[SBORNPLACE],
	[DBIRTHDAT_SBORNPLACE],
	[FATCA],
	[SRAZONSOCIAL]
  )
  SELECT
	[SCLIENT],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [SFIRSTNAME] ),
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [SMIDDLENAME] ),
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [SLASTNAME] ),
	[SSEXCLIEN],
	[TYPE_DOC_FIS],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [DOCUMENT_FIS] ),
	[TYPE_DOC_JUR],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [DOCUMENT_JUR] ),
	[NACIONALTY],
	[CIVILSTA],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [STREET] ),
	[LOCAT],
	[PROVINCE],
	[COUNTRY],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [PHONE] ),
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [EMAIL] ),
	[ACTIVITY],
	[SPECIALITY],
	[ZIPCODE],
	[DATE_REGISTER_INSCR],
	[DATE_CONST],
	[DBIRTHDAT],
	[SBORNPLACE],
	[DBIRTHDAT_SBORNPLACE],
	[FATCA],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [SRAZONSOCIAL] )
  FROM inserted
END;
GO

CREATE VIEW [dbo].[UIFClients] AS
SELECT 
	[SCLIENT],
	CAST(DECRYPTBYKEY( [SFIRSTNAME] ) AS char(19)) [SFIRSTNAME],
	CAST(DECRYPTBYKEY( [SMIDDLENAME] ) AS char(19)) [SMIDDLENAME],
	CAST(DECRYPTBYKEY( [SLASTNAME] ) AS char(19)) [SLASTNAME],
	[SSEXCLIEN],
	[TYPE_DOC_FIS],
	CAST(DECRYPTBYKEY( [DOCUMENT_FIS] ) AS char(50)) [DOCUMENT_FIS],
	[TYPE_DOC_JUR],
	CAST(DECRYPTBYKEY( [DOCUMENT_JUR] ) AS char(50)) [DOCUMENT_JUR],
	[NACIONALTY],
	[CIVILSTA],
	CAST(DECRYPTBYKEY( [STREET] ) AS varchar(121)) [STREET],
	[LOCAT],
	[PROVINCE],
	[COUNTRY],
	CAST(DECRYPTBYKEY( [PHONE] ) AS char(11)) [PHONE],
	CAST(DECRYPTBYKEY( [EMAIL] ) AS char(60)) [EMAIL],
	[ACTIVITY],
	[SPECIALITY],
	[ZIPCODE],
	[DATE_REGISTER_INSCR],
	[DATE_CONST],
	[DBIRTHDAT],
	[SBORNPLACE],
	[DBIRTHDAT_SBORNPLACE],
	[FATCA],	
	CAST(DECRYPTBYKEY( [SRAZONSOCIAL] ) AS varchar(60)) [SRAZONSOCIAL]
FROM UIFClientsEncrypt
GO
CREATE TRIGGER [dbo].[UIFClientsTg] on [dbo].[UIFClients]
INSTEAD OF INSERT
AS
BEGIN
  INSERT INTO [UIFClientsEncrypt] (
	[SCLIENT],
	[SFIRSTNAME],
	[SMIDDLENAME],
	[SLASTNAME],
	[SSEXCLIEN],
	[TYPE_DOC_FIS],
	[DOCUMENT_FIS],
	[TYPE_DOC_JUR],
	[DOCUMENT_JUR],
	[NACIONALTY],
	[CIVILSTA],
	[STREET],
	[LOCAT],
	[PROVINCE],
	[COUNTRY],
	[PHONE],
	[EMAIL],
	[ACTIVITY],
	[SPECIALITY],
	[ZIPCODE],
	[DATE_REGISTER_INSCR],
	[DATE_CONST],
	[DBIRTHDAT],
	[SBORNPLACE],
	[DBIRTHDAT_SBORNPLACE],
	[FATCA],
	[SRAZONSOCIAL]
  )
  SELECT
	[SCLIENT],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [SFIRSTNAME] ),
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [SMIDDLENAME] ),
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [SLASTNAME] ),
	[SSEXCLIEN],
	[TYPE_DOC_FIS],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [DOCUMENT_FIS] ),
	[TYPE_DOC_JUR],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [DOCUMENT_JUR] ),
	[NACIONALTY],
	[CIVILSTA],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [STREET] ),
	[LOCAT],
	[PROVINCE],
	[COUNTRY],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [PHONE] ),
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [EMAIL] ),
	[ACTIVITY],
	[SPECIALITY],
	[ZIPCODE],
	[DATE_REGISTER_INSCR],
	[DATE_CONST],
	[DBIRTHDAT],
	[SBORNPLACE],
	[DBIRTHDAT_SBORNPLACE],
	[FATCA],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [SRAZONSOCIAL] )
  FROM inserted
END;
GO

