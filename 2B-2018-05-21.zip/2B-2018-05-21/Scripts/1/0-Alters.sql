ALTER TABLE Banks ALTER COLUMN [varchar](50) NOT NULL

GO

ALTER PROCEDURE [dbo].[GetSignatureRequestsByClient]
	@clientId     varchar(15) = NULL,
	@PolicyNumber varchar(15) = NULL
AS
BEGIN

	SET NOCOUNT ON;

	 SELECT DISTINCT S.[Id],
			S.PolicyNumber,
			DocumentType,
			DestinationContent,
			DocumentId,
			DocumentName,
			CASE
				WHEN [DocumentType] = 5 then 'Aceptación de póliza'
				WHEN [DocumentType] BETWEEN 101 and 250 then 'Enmienda/SAF'
				ELSE NULL
			END AS DocumentTypeDescription,
			p.EmmissionDate,
			dateadd(dd, 30, p.EmmissionDate) as 'AcceptanceDeadline',
			VT.dDocdate DocumentDate, 
			dbo.DocumentState(S.PolicyNumber, s.DocumentType) AS Status /* Funcion que devuelve el ultimo estado del tipo de documento de la poliza*/


	FROM SignatureRequests S, DocumentsVt Vt, Policies P, StatusPols E 
	WHERE CONVERT(FLOAT, S.PolicyNumber) = CONVERT(FLOAT, VT.sOfficialPol)   
	  AND CONVERT(FLOAT, S.PolicyNumber) = CONVERT(FLOAT, P.PolicyNumber)
	  AND S.DocumentType = VT.ncrthecni 
	  AND VT.dNulldate IS NULL /* Solo se toma el ultimo registro vigente de la tabla VT*/
	  AND (s.DocumentType = 5 OR (s.DocumentType BETWEEN 101 and 250))
	  AND S.PolicyStatus is NULL /* Nunca la poliza pasó a estar inactiva*/
	  AND P.PolicyNumber like '0%'
	
	  AND (S.ClientId     = @clientId     OR @clientId IS NULL) 
	  AND (convert(float, S.PolicyNumber) = convert(float, @PolicyNumber) OR @PolicyNumber IS NULL)

	  AND P.StatusDesc = E.Status 
	  AND E.IsDeleted = 0 /* Estados Habilitados*/
	  AND E.IsActive = 1  /* Solo polizas activas*/

	  AND S.SignatureOnlineStatus   = 'Pendiente'
	  AND S.SignatureInPersonStatus IS NULL
	  AND dbo.DocumentState(S.PolicyNumber, s.DocumentType) = 'Pendiente'
	  AND S.ProcedureNumber is NULL /* No se han firmado anteriormente */
 
 END
 
 
 GO
 
 ALTER TABLE PoliciesEncrypt ADD [IVA] [decimal](10, 2) NULL

GO

ALTER TABLE PoliciesImport ADD [IVA] [decimal](10, 2) NULL

GO

ALTER VIEW [dbo].[PoliciesInsert] AS 
SELECT [ApplicationId]
      ,[PolicyNumber]
      ,[LifePlannerId]
      ,[ClientId]
      ,[InsuredClientId]
      ,[Status]
      ,[StatusDesc]
      ,[StartDate]
      ,[EmmissionDate]
      ,[EndDate]
      ,[LastChangeDate]
      ,[BillMode]
      ,[Currency]
      ,CAST(DECRYPTBYKEY( [PaymentMethod] ) AS varchar(40)) [PaymentMethod]
      ,[AutomaticPayment]
      ,[CashEnhac]
      ,[StampTax]
      ,[SSNTax]
      ,[IIBBTax]
      ,[PolicyFee]
      ,[FundsMainAccount]
      ,[FundsAdditional]
      ,[RescueMainAccount]
      ,[RescueAdditional]
      ,[LoanAmount]
      ,[LastSystemUpdate]
	  ,[LastRescueAccountUpdate]
      ,[RescueTemp]
      ,[Rescue]
      ,[GuaranteedRate]
      ,[Product]
      ,[SumInsured]
      ,[Premium]
      ,CAST(DECRYPTBYKEY( [PaymentAccount] ) AS varchar(80)) [PaymentAccount]
      ,CAST(DECRYPTBYKEY( [MailingAddress] ) AS varchar(100)) [MailingAddress]
      ,[MailingZipcode]
      ,[MailingCity]
      ,[MailingState]
	  ,[LastLoanUpdate]
      ,[LastInvoiceUpdate]
      ,CAST(DECRYPTBYKEY( [LPLastName] ) AS varchar(50)) [LPLastName] 
      ,CAST(DECRYPTBYKEY( [LPFirstName] ) AS varchar(50)) [LPFirstName]
      ,[GuranteedRate]
	  ,CAST(DECRYPTBYKEY( [LPTelephone] ) AS varchar(24)) [LPTelephone]
      ,CAST(DECRYPTBYKEY( [LPMobile] ) AS varchar(24)) [LPMobile]
      ,CAST(DECRYPTBYKEY( [LPEMail] ) AS varchar(70)) [LPEMail]
      ,[GuranteedRateAdditionalFunds]
	  	,[ShowFondRescGarantizados]
		,[FondoGarantCtaPpal]
		,[FondoGarantCtaAdic]
		,[RescateGarantCtaPpal]
		,[RescateGarantCtaAdic]
		,[RescateGarantProrSald]
		,[IVA]
  FROM [dbo].[PoliciesImport]

  GO
  
ALTER TRIGGER [dbo].[PoliciesInsertTg] on [dbo].[PoliciesInsert]
INSTEAD OF INSERT
AS
BEGIN
  --Build an INSERT statement ignoring inserted.ID and 
  --inserted.ComputedCol.
  INSERT INTO [PoliciesImport] (
       [ApplicationId]
      ,[PolicyNumber]
      ,[LifePlannerId]
      ,[ClientId]
      ,[InsuredClientId]
      ,[Status]
      ,[StatusDesc]
      ,[StartDate]
      ,[EmmissionDate]
      ,[EndDate]
      ,[LastChangeDate]
      ,[BillMode]
      ,[Currency]
      ,[PaymentMethod]
      ,[AutomaticPayment]
      ,[CashEnhac]
      ,[StampTax]
      ,[SSNTax]
      ,[IIBBTax]
      ,[PolicyFee]
      ,[FundsMainAccount]
      ,[FundsAdditional]
      ,[RescueMainAccount]
      ,[RescueAdditional]
      ,[LoanAmount]
      ,[LastSystemUpdate]
	  ,[LastRescueAccountUpdate]
      ,[RescueTemp]
      ,[Rescue]
      ,[GuaranteedRate]
      ,[Product]
      ,[SumInsured]
      ,[Premium]
      ,[PaymentAccount]
      ,[MailingAddress]
      ,[MailingZipcode]
      ,[MailingCity]
      ,[MailingState]
	  ,[LastLoanUpdate]
      ,[LastInvoiceUpdate]
      ,[LPLastName] 
      ,[LPFirstName]
      ,[GuranteedRate]
	  ,[LPTelephone]
      ,[LPMobile]
      ,[LPEMail]
      ,[GuranteedRateAdditionalFunds]
	  	,[ShowFondRescGarantizados]
		,[FondoGarantCtaPpal]
		,[FondoGarantCtaAdic]
		,[RescateGarantCtaPpal]
		,[RescateGarantCtaAdic]
		,[RescateGarantProrSald]
		,[IVA]
  )
  SELECT
       [ApplicationId]
      ,[PolicyNumber]
      ,[LifePlannerId]
      ,[ClientId]
      ,[InsuredClientId]
      ,[Status]
      ,[StatusDesc]
      ,[StartDate]
      ,[EmmissionDate]
      ,[EndDate]
      ,[LastChangeDate]
      ,[BillMode]
      ,[Currency]
      ,encryptbykey(Key_GUID('CustomerAccessDataKey'), [PaymentMethod])
      ,[AutomaticPayment]
      ,[CashEnhac]
      ,[StampTax]
      ,[SSNTax]
      ,[IIBBTax]
      ,[PolicyFee]
      ,[FundsMainAccount]
      ,[FundsAdditional]
      ,[RescueMainAccount]
      ,[RescueAdditional]
      ,[LoanAmount]
      ,[LastSystemUpdate]
	  ,[LastRescueAccountUpdate]
      ,[RescueTemp]
      ,[Rescue]
      ,[GuaranteedRate]
      ,[Product]
      ,[SumInsured]
      ,[Premium]
      ,encryptbykey(Key_GUID('CustomerAccessDataKey'), [PaymentAccount])
      ,encryptbykey(Key_GUID('CustomerAccessDataKey'), [MailingAddress])
      ,[MailingZipcode]
      ,[MailingCity]
      ,[MailingState]
	  ,[LastLoanUpdate]
      ,[LastInvoiceUpdate]
      ,encryptbykey(Key_GUID('CustomerAccessDataKey'), [LPLastName])
      ,encryptbykey(Key_GUID('CustomerAccessDataKey'), [LPFirstName])
      ,[GuranteedRate]
	  ,encryptbykey(Key_GUID('CustomerAccessDataKey'), [LPTelephone])
      ,encryptbykey(Key_GUID('CustomerAccessDataKey'), [LPMobile])
      ,encryptbykey(Key_GUID('CustomerAccessDataKey'), [LPEMail])
      ,[GuranteedRateAdditionalFunds]
	  	,[ShowFondRescGarantizados]
		,[FondoGarantCtaPpal]
		,[FondoGarantCtaAdic]
		,[RescateGarantCtaPpal]
		,[RescateGarantCtaAdic]
		,[RescateGarantProrSald]
		,[IVA]
       FROM inserted
END;

GO

ALTER VIEW [dbo].[SignatureRequestsMail] AS
SELECT s.ClientId, 
	   s.DocumentType, 
	   ee.EMail,
	   c.MailingPreference,
	   p.PolicyNumber
FROM SignatureRequests s INNER JOIN DocumentsVt vt 
      ON CONVERT(FLOAT, CASE WHEN ISNUMERIC(s.PolicyNumber) = 1 THEN s.PolicyNumber ELSE 0 END) = CONVERT(FLOAT, CASE WHEN ISNUMERIC(VT.sOfficialPol) = 1 THEN VT.sOfficialPol ELSE 1 END) 
	 AND s.DocumentType = vt.ncrthecni

	INNER JOIN Policies p ON CONVERT(FLOAT, CASE WHEN ISNUMERIC(S.PolicyNumber) = 1 THEN S.PolicyNumber ELSE 0 END) = CONVERT(FLOAT, CASE WHEN ISNUMERIC(P.PolicyNumber) = 1 THEN P.PolicyNumber ELSE 1 END) 
    INNER JOIN Clients c ON p.ClientId = c.ClientId 
	
	/* Comentado por GSantoro 08/05/2018  visto con G. Judid 
	AND c.ClientId = s.ClientId
	*/
	
	INNER JOIN StatusPols e ON p.StatusDesc = e.Status 
	INNER JOIN EMailsEncrypt ee ON ee.ClientId = p.ClientId
	INNER JOIN DocumentLetters dl 
	
	/* Agregado por Gsantoro 08/05/2018 */
	ON CONVERT(FLOAT, CASE WHEN ISNUMERIC(dl.PolicyNumber) = 1 THEN dl.PolicyNumber ELSE 0 END) = CONVERT(FLOAT, CASE WHEN ISNUMERIC(P.PolicyNumber) = 1 THEN P.PolicyNumber ELSE 1 END) 
	--dl.PolicyNumber = p.PolicyNumber

WHERE vt.dNulldate IS NULL /* Solo se toma el ultimo registro vigente de la tabla VT*/
  AND (s.DocumentType = 5 OR (s.DocumentType BETWEEN 101 and 250))
  AND s.PolicyStatus is NULL /* Nunca la poliza pasó a estar inactiva*/
  AND p.PolicyNumber like '0%'  
  AND e.IsDeleted = 0 /* Estados Habilitados*/
  AND e.IsActive = 1  /* Solo polizas activas*/
  AND (s.SignatureOnlineStatus = 'Pendiente' OR s.SignatureOnlineStatus IS NULL)
  AND (s.SignatureInPersonStatus = 'Pendiente' OR s.SignatureInPersonStatus IS NULL)
  AND vt.nStat_docReq = 1 --'Pendiente'
  AND s.ProcedureNumber is NULL /* No se han firmado anteriormente */
  AND s.DestinationContent = 'TOMADOR'
  AND DATEADD(DAY, 7, vt.dDocdate) <= GETDATE()  
  AND dl.LetterCode = 'EDL'
  
GO

ALTER TABLE TransactionRequests ALTER COLUMN [ApplicationId] [varchar](15) NULL

GO

ALTER TABLE TransactionRequests ADD GroupId [bigint] NULL

GO

ALTER TABLE CREATE TABLE VtimeTransactionStates(
	Id INT NOT NULL PRIMARY KEY,
	Description VARCHAR(200) NOT NULL
)

GO

---INSERT INTO VtimeTransactionStates (Id, Description) VALUES (0, 'default')
INSERT INTO VtimeTransactionStates (Id, Description) VALUES (1, 'No Procesado')
INSERT INTO VtimeTransactionStates (Id, Description) VALUES (2, 'En Proceso')
INSERT INTO VtimeTransactionStates (Id, Description) VALUES (3, 'Procesado')
INSERT INTO VtimeTransactionStates (Id, Description) VALUES (4, 'Pendiente de Confirmación de Email')

GO

ALTER TABLE TransactionRequests ADD VtimeStateId INT NULL

GO

UPDATE TransactionRequests
SET VtimeStateId = (SELECT Id FROM VtimeTransactionStates WHERE Description = 'No Procesado')
WHERE ProcessedVT = 0

GO

UPDATE TransactionRequests
SET VtimeStateId = (SELECT Id FROM VtimeTransactionStates WHERE Description = 'Procesado')
WHERE ProcessedVT = 1

GO

ALTER TABLE TransactionRequests ALTER COLUMN VtimeStateId INT NOT NULL

GO

ALTER TABLE TransactionRequests ADD CONSTRAINT TransactionRequests_VtimeTransactionStates FOREIGN KEY (VtimeStateId) REFERENCES VtimeTransactionStates(Id)

GO

ALTER TABLE TransactionRequests DROP COLUMN ProcessedVT

GO

ALTER TABLE VtimeTransactionStates ADD ClientDescription VARCHAR(200)

GO

UPDATE VtimeTransactionStates SET ClientDescription = 'Pendiente' WHERE Description = 'No Procesado'
UPDATE VtimeTransactionStates SET ClientDescription = 'En Proceso' WHERE Description = 'En Proceso'
UPDATE VtimeTransactionStates SET ClientDescription = 'Procesado' WHERE Description = 'Confirmado'
UPDATE VtimeTransactionStates SET ClientDescription = 'Pendiente de Confirmación de Email' WHERE Description = 'Pendiente de Confirmación de Email'
UPDATE VtimeTransactionStates SET ClientDescription = 'Procesado' WHERE Description = 'Procesado'


GO

ALTER TABLE Users ADD [RegistrationDate] [datetime] NULL

GO

ALTER TABLE [dbo].[Users] ADD  DEFAULT (getdate()) FOR [RegistrationDate]