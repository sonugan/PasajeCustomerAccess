---ChangeMailRequests
CREATE TABLE [dbo].[ChangeMailRequestsEncrypt](
	[Id] [bigint] NOT NULL,
	[Mail] [varbinary](max) NOT NULL,
	[Confirm] [bit] NOT NULL,
	[TokenValidate] [varchar](300) NOT NULL,
 CONSTRAINT [PK_ChangeMailRequestsEncrypt] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

OPEN SYMMETRIC KEY CustomerAccessDataKey DECRYPTION BY CERTIFICATE SSISCertificate
	INSERT INTO [ChangeMailRequestsEncrypt] (
	[Id],
	[Mail],
	[Confirm],
	[TokenValidate]
  )
  SELECT
	[Id],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [Mail] ),
	[Confirm],
	[TokenValidate]
  FROM ChangeMailRequests;
IF((SELECT SUM(ISNULL(status, 0)) FROM sys.openkeys) > 0) CLOSE SYMMETRIC KEY CustomerAccessDataKey

GO

DROP TABLE ChangeMailRequests

GO

CREATE VIEW [dbo].[ChangeMailRequests] AS
SELECT 
	[Id],
	CAST(DECRYPTBYKEY( [Mail] ) AS varchar(50)) [Mail],
	[Confirm],
	[TokenValidate]
FROM [ChangeMailRequestsEncrypt]

GO

CREATE TRIGGER [dbo].[ChangeMailRequestsTg] on [dbo].[ChangeMailRequests]
INSTEAD OF INSERT
AS
BEGIN
  INSERT INTO [ChangeMailRequestsEncrypt] (
	[Id],
	[Mail],
	[Confirm],
	[TokenValidate]
  )
  SELECT
	[Id],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [Mail] ),
	[Confirm],
	[TokenValidate]
  FROM inserted
END;