INSERT INTO [dbo].[EMailsTemplates]
           ([Id]
           ,[Asunto]
           ,[Mensaje]
           ,[CCaLP])
     VALUES
           (56
           ,'Prudential Seguros - Cambio de dirección de e-mail'
           ,
		   '<p>Estimado/a cliente: </p>
			<p>Hemos recibido una solicitud de cambio de e-mail.</p>
			<p>Por favor validá tu e-mail haciendo click a continuación.</p>
			<p style="text-align: center;"><a href="URL_BASE" style="
				background-color: #0174DF;
				color: #fff;
				border: 1px solid #81DAF5;
				padding: 5px 20px 5px 20px;
				border-radius: 8px;
				text-decoration: none;
			">Validá tu Email</a></p>
			<p>Autorizo a Prudential Seguros S.A. a enviarme por correo electrónico o mediante puesta a disposición en la página web prudential.com.ar, cualquier información, documentación o notificación relacionada con mi Póliza de Seguro de Vida, aun cuando la misma incluya datos confidenciales/sensibles. Constituyo ambos medios como domicilio válido de notificación.</p>
			<p>Ante cualquier inconveniente no dudes en contactarnos vía e-mail a atencionalasegurado@prudential.com o bien telefónicamente a la siguiente línea gratuita: 0-800-777-PRUD(7783).</p>
			<p>Muchas gracias por utilizar nuestros servicios.</p>
			<p>Prudential Seguros S.A. </p>'
           ,0)