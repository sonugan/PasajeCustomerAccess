DROP TABLE AddressTypes
GO
DROP TABLE Documentos_VT
GO
DROP PROCEDURE GetPoliciesPendingSignatureByUser_sofre