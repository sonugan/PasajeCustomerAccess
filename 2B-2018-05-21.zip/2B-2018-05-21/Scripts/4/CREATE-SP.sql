CREATE Procedure [dbo].[Insert_UIFRequests]
AS

/* Este procedimiento se ejecutará una vez al dia y la funcion es la de incorporar
los nuevos requerimientos para la actualizacion de los datos personales conforme
 a la normativa de la UIF de lavado de dinero.

El evento que dará origen a los requerimientos será la publicacion los documentos del tipo:
"RAP" =  Documentacion Annual de la poliza

EXEC Insert_UIFRequests
*/

SET NOcount  ON

DECLARE @RequestDate DATETIME2
SELECT @RequestDate = GETDATE()

INSERT INTO UIFRequests 
(ClientID, 
RequestYear, 
RequestState,
PolicyNumber
)
Select 
P.ClientId, 
DATEPART(YY, DL.ProccessDate), 
1, /* 1 = Pendiente, 2 = Finalizado */
MIN(DL.PolicyNumber)
from documentletters  DL, Policies P
WHERE DL.PolicyNumber = P.PolicyNumber
  AND DL.LetterCode = 'RAP'
  AND NOT EXISTS(SELECT 1 FROM UIFRequests UI2
	    		 WHERE DATEPART(YY,DL.ProccessDate) = UI2.Requestyear
				   AND UI2.clientID = P.ClientID
			     )
GROUP BY P.ClientId, DATEPART(YY, DL.ProccessDate)

GO

CREATE PROCEDURE [dbo].[InsertUIFInformationLegalPerson] 
	@TransactionRequestId BIGINT,
	@UIFRequestId BIGINT,
	@UIFRegisterType INT,
	@Address1 VARCHAR(50) = NULL,
	@Address2 VARCHAR(50) = NULL,
	@ZipCode VARCHAR(8) = NULL,
	@LocalityId INT = NULL,
	@ProvinceId INT = NULL,
	@PhoneCountryCode VARCHAR(50) = NULL,
	@PhoneProvinceCode VARCHAR(50) = NULL,
	@PhoneNumber VARCHAR(50) = NULL,
	@EMail VARCHAR(50) = NULL,
	@HasForeignNationality BIT = NULL,
	@BusinessName VARCHAR(50) = NULL,
	@LegalRepresentativeFirstName VARCHAR(50) = NULL,
	@LegalRepresentativeLastName VARCHAR(50) = NULL,
	@EnrollmentDate DATETIME = NULL,
	@EnrollmentNumber INT = NULL,
	@ConstitutiveActDate DATETIME = NULL,
	@DocumentNumber VARCHAR(50) = NULL,
	@BusinessActivityId INT = NULL
AS
BEGIN

	INSERT INTO [dbo].[UIFInformationLegalPersonsEncrypt]
           ([TransactionRequestId]
           ,[CreationDate]
           ,[UIFRequestId]
           ,[UIFRegisterType]
           ,[UIFTypeUpdateDate]
           ,[Address1]
           ,[Address2]
           ,[ZipCode]
           ,[LocalityId]
           ,[ProvinceId]
           ,[PhoneCountryCode]
           ,[PhoneProvinceCode]
           ,[PhoneNumber]
           ,[EMail]
           ,[HasForeignNationality]
		   ,[BusinessName]
           ,[LegalRepresentativeFirstName]
           ,[LegalRepresentativeLastName]
           ,[EnrollmentDate]
           ,[EnrollmentNumber]
           ,[ConstitutiveActDate]
           ,[DocumentNumber]
           ,[BusinessActivityId])
     VALUES
           (@TransactionRequestId
		   ,GETDATE()
           ,@UIFRequestId
           ,@UIFRegisterType
           ,GETDATE()
		   ,encryptbykey(Key_GUID('CustomerAccessDataKey'), @Address1 )
		   ,encryptbykey(Key_GUID('CustomerAccessDataKey'), @Address2 )
           ,@ZipCode
           ,@LocalityId
           ,@provinceId
		   ,encryptbykey(Key_GUID('CustomerAccessDataKey'), @PhoneCountryCode )
		   ,encryptbykey(Key_GUID('CustomerAccessDataKey'), @PhoneProvinceCode )
		   ,encryptbykey(Key_GUID('CustomerAccessDataKey'), @PhoneNumber )
		   ,encryptbykey(Key_GUID('CustomerAccessDataKey'), @EMail )
           ,@HasForeignNationality
		   ,encryptbykey(Key_GUID('CustomerAccessDataKey'), @BusinessName )
		   ,encryptbykey(Key_GUID('CustomerAccessDataKey'), @LegalRepresentativeFirstName )
		   ,encryptbykey(Key_GUID('CustomerAccessDataKey'), @LegalRepresentativeLastName )
           ,@EnrollmentDate
           ,@EnrollmentNumber
           ,@ConstitutiveActDate
		   ,encryptbykey(Key_GUID('CustomerAccessDataKey'), @DocumentNumber )
           ,@BusinessActivityId);
		   
	SELECT @@IDENTITY AS 'Id';  

END

GO

CREATE PROCEDURE [dbo].[InsertUIFInformationNaturalPerson]  
	@TransactionRequestId bigint = NULL,
	@UIFRequestId bigint = NULL,
	@UIFRegisterType int = NULL,
	@Address1 varchar(50) = NULL,
	@Address2 varchar(50) = NULL,
	@ZipCode varchar(8) = NULL,
	@LocalityId int = NULL,
	@ProvinceId int = NULL,
	@PhoneCountryCode varchar(50) = NULL,
	@PhoneProvinceCode varchar(50) = NULL,
	@PhoneNumber varchar(50) = NULL,
	@EMail varchar(50) = NULL,
	@HasForeignNationality bit = NULL,
	@FirstName varchar(50) = NULL,
	@LastName varchar(50) = NULL,
	@BirthDate datetime = NULL,
	@PlaceBirth varchar(50) = NULL,
	@GenderId int = NULL,
	@NationalityId int = NULL,
	@MaritalStatusId int = NULL,
	@DocumentTypeId int = NULL,
	@DocumentNumber varchar(50) = NULL,
	@TributeKeyTypeId int = NULL,
	@TributeKey varchar(50) = NULL,
	@ProfessionId int = NULL

AS 
BEGIN 

INSERT INTO [dbo].[UIFInformationNaturalPersonsEncrypt]
           ([TransactionRequestId]
           ,[CreationDate]
           ,[UIFRequestId]
           ,[UIFRegisterType]
           ,[UIFTypeUpdateDate]
           ,[Address1]
           ,[Address2]
           ,[ZipCode]
           ,[LocalityId]
           ,[ProvinceId]
           ,[PhoneCountryCode]
           ,[PhoneProvinceCode]
           ,[PhoneNumber]
           ,[EMail]
           ,[HasForeignNationality]
           ,[FirstName]
           ,[LastName]
           ,[BirthDate]
           ,[PlaceBirth]
           ,[GenderId]
           ,[NationalityId]
           ,[MaritalStatusId]
           ,[DocumentTypeId]
           ,[DocumentNumber]
           ,[TributeKeyTypeId]
           ,[TributeKey]
           ,[ProfessionId])
     VALUES
           (@TransactionRequestId,
           GETDATE(),
           @UIFRequestId,
           @UIFRegisterType,
           GETDATE(),
           encryptbykey(Key_GUID('CustomerAccessDataKey'), @Address1),
           encryptbykey(Key_GUID('CustomerAccessDataKey'), @Address2),
           @ZipCode,
           @LocalityId,
           @ProvinceId,
		   encryptbykey(Key_GUID('CustomerAccessDataKey'), @PhoneCountryCode),
           encryptbykey(Key_GUID('CustomerAccessDataKey'), @PhoneProvinceCode),
           encryptbykey(Key_GUID('CustomerAccessDataKey'), @PhoneNumber),
		   encryptbykey(Key_GUID('CustomerAccessDataKey'), @EMail),
           @HasForeignNationality,
		   encryptbykey(Key_GUID('CustomerAccessDataKey'), @FirstName),
		   encryptbykey(Key_GUID('CustomerAccessDataKey'), @LastName),
           @BirthDate,
           @PlaceBirth,
           @GenderId,
           @NationalityId,
           @MaritalStatusId,
           @DocumentTypeId,
		   encryptbykey(Key_GUID('CustomerAccessDataKey'), @DocumentNumber),
           @TributeKeyTypeId,
		   encryptbykey(Key_GUID('CustomerAccessDataKey'), @TributeKey),
           @ProfessionId);


	SELECT @@IDENTITY AS 'Id';  

END 


GO

ALTER PROCEDURE [dbo].[sp_swap_tables]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

BEGIN TRY
ALTER TABLE AddressesEncrypt  
DROP CONSTRAINT FK_Addresses_ClientId
;
END TRY
BEGIN CATCH
END CATCH

BEGIN TRY
ALTER TABLE BeneficiariesEncrypt  
DROP CONSTRAINT FK_Beneficiaries_ApplicationId
;
END TRY
BEGIN CATCH
END CATCH

BEGIN TRY
ALTER TABLE EMailsEncrypt  
DROP CONSTRAINT FK_EMails_ClientId
;
END TRY
BEGIN CATCH
END CATCH

BEGIN TRY
ALTER TABLE PhoneNumbersEncrypt  
DROP CONSTRAINT FK_PhoneNumbers_ClientId
;
END TRY
BEGIN CATCH
END CATCH

BEGIN TRY
ALTER TABLE ProductsEncrypt  
DROP CONSTRAINT FK_Products_ApplicationId
;
END TRY
BEGIN CATCH
END CATCH

BEGIN TRY
ALTER TABLE PoliciesEncrypt  
DROP CONSTRAINT FK_Policies_ClientId
;
END TRY
BEGIN CATCH
END CATCH

BEGIN TRY
ALTER TABLE PaymentsEncrypt  
DROP CONSTRAINT FK_Payments_ApplicationId
;
END TRY
BEGIN CATCH
END CATCH

BEGIN TRY
ALTER TABLE MovementHistoryEncrypt  
DROP CONSTRAINT FK_MovementHistory_Products
;
END TRY
BEGIN CATCH
END CATCH

BEGIN TRY
ALTER TABLE PoliciesEncrypt  
DROP CONSTRAINT FK_Policies_InsuredClientId
;
END TRY
BEGIN CATCH
END CATCH


EXEC sp_rename 'dbo.BeneficiariesImport', 'BeneficiariesTmp'; 
EXEC sp_rename 'dbo.AddressesImport', 'AddressesTmp'; 
EXEC sp_rename 'dbo.ClientsImport', 'ClientsTmp'; 
EXEC sp_rename 'dbo.EMailsImport', 'EMailsTmp'; 
EXEC sp_rename 'dbo.MovementHistoryImport', 'MovementHistoryTmp';  
EXEC sp_rename 'dbo.PaymentsImport', 'PaymentsTmp'; 
EXEC sp_rename 'dbo.PhoneNumbersImport', 'PhoneNumbersTmp'; 
EXEC sp_rename 'dbo.PoliciesImport', 'PoliciesTmp';  
EXEC sp_rename 'dbo.ProductsImport', 'ProductsTmp'; 
EXEC sp_rename 'dbo.RentaDiariaImport', 'RentaDiariaTmp'; 
EXEC sp_rename 'dbo.UIFClientsImport', 'UIFClientsTmp'; 

EXEC sp_rename 'dbo.BeneficiariesEncrypt', 'BeneficiariesImport';  
EXEC sp_rename 'dbo.AddressesEncrypt', 'AddressesImport';  
EXEC sp_rename 'dbo.ClientsEncrypt', 'ClientsImport';  
EXEC sp_rename 'dbo.EMailsEncrypt', 'EMailsImport';  
EXEC sp_rename 'dbo.MovementHistoryEncrypt', 'MovementHistoryImport';
EXEC sp_rename 'dbo.PaymentsEncrypt', 'PaymentsImport';    
EXEC sp_rename 'dbo.PhoneNumbersEncrypt', 'PhoneNumbersImport';  
EXEC sp_rename 'dbo.PoliciesEncrypt', 'PoliciesImport';  
EXEC sp_rename 'dbo.ProductsEncrypt', 'ProductsImport'; 
EXEC sp_rename 'dbo.RentaDiaria', 'RentaDiariaImport'; 
EXEC sp_rename 'dbo.UIFClientsEncrypt', 'UIFClientsImport'; 

EXEC sp_rename 'dbo.BeneficiariesTmp', 'BeneficiariesEncrypt';  
EXEC sp_rename 'dbo.AddressesTmp', 'AddressesEncrypt';  
EXEC sp_rename 'dbo.ClientsTmp', 'ClientsEncrypt';  
EXEC sp_rename 'dbo.EMailsTmp', 'EMailsEncrypt';  
EXEC sp_rename 'dbo.MovementHistoryTmp', 'MovementHistoryEncrypt'; 
EXEC sp_rename 'dbo.PaymentsTmp', 'PaymentsEncrypt';  
EXEC sp_rename 'dbo.PhoneNumbersTmp', 'PhoneNumbersEncrypt'; 
EXEC sp_rename 'dbo.PoliciesTmp', 'PoliciesEncrypt';  
EXEC sp_rename 'dbo.ProductsTmp', 'ProductsEncrypt';  
EXEC sp_rename 'dbo.RentaDiariaTmp', 'RentaDiaria'; 
EXEC sp_rename 'dbo.UIFClientsTmp', 'UIFClientsEncrypt';

IF 1=0
BEGIN
	BEGIN TRY
	ALTER TABLE AddressesEncrypt WITH NOCHECK 
	ADD CONSTRAINT FK_Addresses_ClientId FOREIGN KEY ( ClientId ) REFERENCES ClientsEncrypt (ClientId)
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE AddressesEncrypt NOCHECK CONSTRAINT FK_Addresses_ClientId
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE BeneficiariesEncrypt WITH NOCHECK 
	ADD CONSTRAINT FK_Beneficiaries_ApplicationId FOREIGN KEY ( ApplicationId ) REFERENCES PoliciesEncrypt (ApplicationId)
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE BeneficiariesEncrypt NOCHECK CONSTRAINT FK_Beneficiaries_ApplicationId
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE EMailsEncrypt WITH NOCHECK 
	ADD CONSTRAINT FK_EMails_ClientId FOREIGN KEY ( ClientId ) REFERENCES ClientsEncrypt (ClientId)
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE EMailsEncrypt NOCHECK CONSTRAINT FK_EMails_ClientId
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE PhoneNumbersEncrypt WITH NOCHECK 
	ADD CONSTRAINT FK_PhoneNumbers_ClientId FOREIGN KEY ( ClientId ) REFERENCES ClientsEncrypt (ClientId)
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE PhoneNumbersEncrypt NOCHECK CONSTRAINT FK_PhoneNumbers_ClientId
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE ProductsEncrypt WITH NOCHECK 
	ADD CONSTRAINT FK_Products_ApplicationId FOREIGN KEY ( ApplicationId ) REFERENCES PoliciesEncrypt (ApplicationId)
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE ProductsEncrypt NOCHECK CONSTRAINT FK_Products_ApplicationId
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE PoliciesEncrypt WITH NOCHECK 
	ADD CONSTRAINT FK_Policies_ClientId FOREIGN KEY ( ClientId ) REFERENCES ClientsEncrypt (ClientId)
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE PoliciesEncrypt NOCHECK CONSTRAINT FK_Policies_ClientId
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE PaymentsEncrypt WITH NOCHECK 
	ADD CONSTRAINT FK_Payments_ApplicationId FOREIGN KEY ( ApplicationId ) REFERENCES PoliciesEncrypt (ApplicationId)
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE PaymentsEncrypt NOCHECK CONSTRAINT FK_Payments_ApplicationId
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE MovementHistoryEncrypt WITH NOCHECK 
	ADD CONSTRAINT FK_MovementHistory_Products FOREIGN KEY ( ApplicationId, Coverage, Transact ) REFERENCES ProductsEncrypt (ApplicationId, Coverage, Transact)
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE MovementHistoryEncrypt NOCHECK CONSTRAINT FK_MovementHistory_Products
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE PoliciesEncrypt WITH NOCHECK 
	ADD CONSTRAINT FK_Policies_InsuredClientId FOREIGN KEY ( InsuredClientId ) REFERENCES ClientsEncrypt (ClientId)
	;
	END TRY
	BEGIN CATCH
	END CATCH

	BEGIN TRY
	ALTER TABLE PoliciesEncrypt NOCHECK CONSTRAINT FK_Policies_InsuredClientId
	;
	END TRY
	BEGIN CATCH
	END CATCH
END

END

GO

CREATE Procedure [dbo].[UIFRequests_Consul]
AS


/* Consulta de transacciones UIF para personas fisicas */ 
SELECT 
 R.ClientId        
,R.RequestYear 
,R.RequestDate             
,R.UpdateDate              
,CASE R.RequestState  WHEN 1 THEN 'Pendiente' ELSE 'Confirmado' END as 'RequestState'
,P.TransactionRequestId
,P.Id
,P.CreationDate            
,P.UIFRequestId         
, CASE P.UIFRegisterType WHEN 1 THEN 'Anterior' WHEN 2 THEN 'Nuevo' END AS 'UIFRegisterType'
,P.UIFTypeUpdateDate       
,P.Address1                                           
,P.Address2                                           
,P.ZipCode  
,P.LocalityId                                         
,P.ProvinceId  
,P.PhoneCountryCode 
,P.PhoneProvinceCode 
,P.PhoneNumber 
,P.EMail    
,NP.FirstName                                          
,NP.LastName                                           
,NP.BirthDate               
,NP.PlaceBirth                                         
,NP.GenderId    
,NP.NationalityId 
,NP.MaritalStatusId 
,NP.DocumentTypeId 
,NP.DocumentNumber                                     
,NP.TributeKeyTypeId 
,NP.TributeKey                                         
,NP.ProfessionId
,CASE P.HasForeignNationality WHEN 0 THEN 'NO' WHEN 1 THEN 'SI' END as 'HasForeignNationality'
,Paises_Anterior.Paises as 'Paises_Anterior'
,Paises_NEW.Paises as 'Paises_Nuevos'
FROM UIFRequests R 
LEFT JOIN UIFInformationPersons P
  ON R.ID = P.UIFRequestId
LEFT JOIN UIFInformationNaturalPersons NP
  ON P.ID = NP.ID
LEFT JOIN (SELECT t1.sclient, 
			( SELECT convert(varchar(5),nCountry)  + ', '  
			  FROM UIFFatca t2 
			  WHERE t1.sclient = t2.sclient
			  ORDER BY 1 desc
			  FOR XML PATH('') 
			) AS Paises 
			FROM UIFFatca t1 
			--where t1.sClient = 'N0000000532605'
			GROUP BY t1.sclient 
		   ) as Paises_Anterior /*  Paises de residencia del cliente */
ON Paises_Anterior.sclient = R.ClientId
AND P.UIFRegisterType = 1

LEFT JOIN (SELECT t1.UIFInformationPersonId, 
			( SELECT convert(varchar(5),CountryId)  + ', '  
			  FROM ForeignNationalities t2 
			  WHERE t1.UIFInformationPersonId= t2.UIFInformationPersonId
			  ORDER BY 1 desc
			  FOR XML PATH('') 
			) AS Paises
			FROM ForeignNationalities t1 
			GROUP BY t1.UIFInformationPersonId
		   ) as Paises_NEW /*  Paises de residencia del cliente */
ON Paises_NEW.UIFInformationPersonId = P.ID
AND P.UIFRegisterType = 2
WHERE R.ClientId like 'N%'
ORDER BY UIFRequestId,UIFRegisterType


/* Consulta de transacciones UIF para personas Juridicas */ 

SELECT 
 R.ClientId        
,R.RequestYear 
,R.RequestDate             
,R.UpdateDate              
,CASE R.RequestState  WHEN 1 THEN 'Pendiente' ELSE 'Confirmado' END as 'RequestState'
,P.TransactionRequestId
,P.Id
,P.CreationDate            
,P.UIFRequestId         
, CASE P.UIFRegisterType WHEN 1 THEN 'Anterior' WHEN 2 THEN 'Nuevo' END AS 'UIFRegisterType'
,P.UIFTypeUpdateDate       
,P.Address1                                           
,P.Address2                                           
,P.ZipCode  
,P.LocalityId                                       
,P.ProvinceId  
,P.PhoneCountryCode 
,P.PhoneProvinceCode 
,P.PhoneNumber 
,P.EMail    
,LP.*
,CASE P.HasForeignNationality WHEN 0 THEN 'NO' WHEN 1 THEN 'SI' END as 'HasForeignNationality'
,Paises_Anterior.Paises as 'Paises_Anterior'
,Paises_NEW.Paises as 'Paises_Nuevos'

FROM UIFRequests R 
LEFT JOIN UIFInformationPersons P
  ON R.ID = P.UIFRequestId
LEFT JOIN [dbo].[UIFInformationLegalPersons] LP
  ON P.ID = LP.ID

LEFT JOIN (SELECT t1.sclient, 
			( SELECT convert(varchar(5),nCountry)  + ', '  
			  FROM UIFFatca t2 
			  WHERE t1.sclient = t2.sclient
			  ORDER BY 1 desc
			  FOR XML PATH('') 
			) AS Paises 
			FROM UIFFatca t1 
			--where t1.sClient = 'N0000000532605'
			GROUP BY t1.sclient 
		   ) as Paises_Anterior /*  Paises de residencia del cliente */
ON Paises_Anterior.sclient = R.ClientId
AND P.UIFRegisterType = 1

LEFT JOIN (SELECT t1.UIFInformationPersonId, 
			( SELECT convert(varchar(5),CountryId)  + ', '  
			  FROM ForeignNationalities t2 
			  WHERE t1.UIFInformationPersonId= t2.UIFInformationPersonId
			  ORDER BY 1 desc
			  FOR XML PATH('') 
			) AS Paises
			FROM ForeignNationalities t1 
			GROUP BY t1.UIFInformationPersonId
		   ) as Paises_NEW /*  Paises de residencia del cliente */
ON Paises_NEW.UIFInformationPersonId = P.ID
AND P.UIFRegisterType = 2
WHERE R.ClientId like 'J%'
ORDER BY UIFRequestId, UIFRegisterType
GO
