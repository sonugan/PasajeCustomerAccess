CREATE TABLE [dbo].[UIFRequests](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[ClientId] [varchar](15) NOT NULL,
	[RequestYear] [int] NOT NULL,
	[RequestDate] [datetime] NOT NULL,
	[UpdateDate] [datetime] NOT NULL,
	[RequestState] [int] NOT NULL,
	[PolicyNumber] [varchar](15) NOT NULL,
 CONSTRAINT [PK_UIFRequests] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UIFRequests_ClientIdRequestState] UNIQUE NONCLUSTERED 
(
	[ClientId] ASC,
	[RequestYear] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[UIFRequests] ADD  CONSTRAINT [DF_UIFRequests_RequestDate]  DEFAULT (getdate()) FOR [RequestDate]
GO
ALTER TABLE [dbo].[UIFRequests] ADD  CONSTRAINT [DF_UIFRequests_UpdateDate]  DEFAULT (getdate()) FOR [UpdateDate]
GO
ALTER TABLE [dbo].[UIFRequests]  WITH CHECK ADD  CONSTRAINT [UIFRequests_RequestYear] CHECK  (([RequestYear]>=(1900) AND [RequestYear]<=(9999)))
GO
ALTER TABLE [dbo].[UIFRequests] CHECK CONSTRAINT [UIFRequests_RequestYear]
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'1-Pendiente; 2-Aceptado' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'UIFRequests', @level2type=N'COLUMN',@level2name=N'RequestState'
GO


CREATE TABLE [dbo].[UIFInformationNaturalPersonsEncrypt](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[TransactionRequestId] [bigint] NULL,
	[CreationDate] [datetime] NULL,
	[UIFRequestId] [bigint] NOT NULL,
	[UIFRegisterType] [int] NOT NULL,
	[UIFTypeUpdateDate] [datetime] NULL,
	[Address1] [varbinary](max) NULL,
	[Address2] [varbinary](max) NULL,
	[ZipCode] [varchar](8) NULL,
	[LocalityId] [int] NULL,
	[ProvinceId] [int] NULL,
	[PhoneCountryCode] [varbinary](max) NULL,
	[PhoneProvinceCode] [varbinary](max) NULL,
	[PhoneNumber] [varbinary](max) NULL,
	[EMail] [varbinary](max) NULL,
	[HasForeignNationality] [bit] NULL,
	[FirstName] [varbinary](max) NULL,
	[LastName] [varbinary](max) NULL,
	[BirthDate] [datetime] NULL,
	[PlaceBirth] [varchar](50) NULL,
	[GenderId] [int] NULL,
	[NationalityId] [int] NULL,
	[MaritalStatusId] [int] NULL,
	[DocumentTypeId] [int] NULL,
	[DocumentNumber] [varbinary](max) NULL,
	[TributeKeyTypeId] [int] NULL,
	[TributeKey] [varbinary](max) NULL,
	[ProfessionId] [int] NULL,
 CONSTRAINT [PK_UIFInformationNaturalPersonsEncrypt] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt]  WITH NOCHECK ADD  CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_Countries] FOREIGN KEY([NationalityId])
REFERENCES [dbo].[Countries] ([Id])
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt] CHECK CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_Countries]
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt]  WITH NOCHECK ADD  CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_DocumentTypes] FOREIGN KEY([DocumentTypeId])
REFERENCES [dbo].[DocumentTypes] ([Id])
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt] CHECK CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_DocumentTypes]
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt]  WITH NOCHECK ADD  CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_Genders] FOREIGN KEY([GenderId])
REFERENCES [dbo].[Genders] ([Id])
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt] CHECK CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_Genders]
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt]  WITH NOCHECK ADD  CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_Localities] FOREIGN KEY([LocalityId])
REFERENCES [dbo].[Localities] ([Id])
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt] CHECK CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_Localities]
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt]  WITH NOCHECK ADD  CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_MaritalStatus] FOREIGN KEY([MaritalStatusId])
REFERENCES [dbo].[MaritalStatus] ([Id])
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt] CHECK CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_MaritalStatus]
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt]  WITH NOCHECK ADD  CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_Professions] FOREIGN KEY([ProfessionId])
REFERENCES [dbo].[Professions] ([Id])
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt] CHECK CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_Professions]
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt]  WITH NOCHECK ADD  CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_Provinces] FOREIGN KEY([ProvinceId])
REFERENCES [dbo].[Provinces] ([Id])
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt] CHECK CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_Provinces]
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt]  WITH NOCHECK ADD  CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_TransactionRequests] FOREIGN KEY([TransactionRequestId])
REFERENCES [dbo].[TransactionRequests] ([Id])
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt] CHECK CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_TransactionRequests]
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt]  WITH NOCHECK ADD  CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_TributeKeyTypes] FOREIGN KEY([TributeKeyTypeId])
REFERENCES [dbo].[TributeKeyTypes] ([Id])
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt] CHECK CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_TributeKeyTypes]
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt]  WITH NOCHECK ADD  CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_UIFRequests] FOREIGN KEY([UIFRequestId])
REFERENCES [dbo].[UIFRequests] ([Id])
GO
ALTER TABLE [dbo].[UIFInformationNaturalPersonsEncrypt] CHECK CONSTRAINT [FK_UIFInformationNaturalPersonsEncrypt_UIFRequests]
GO

create VIEW [dbo].[UIFInformationNaturalPersons] AS
SELECT 
	[Id],
	[TransactionRequestId],
	[CreationDate],
	[UIFRequestId],
	[UIFRegisterType],
	[UIFTypeUpdateDate],
	CAST(DECRYPTBYKEY( [Address1] ) AS varchar(50)) [Address1],
	CAST(DECRYPTBYKEY( [Address2] ) AS varchar(50)) [Address2],
	[ZipCode],
	[LocalityId],
	[ProvinceId],
	CAST(DECRYPTBYKEY( [PhoneCountryCode] ) AS varchar(50)) [PhoneCountryCode],
	CAST(DECRYPTBYKEY( [PhoneProvinceCode] ) AS varchar(50)) [PhoneProvinceCode],
	CAST(DECRYPTBYKEY( [PhoneNumber] ) AS varchar(50)) [PhoneNumber],
	CAST(DECRYPTBYKEY( [EMail] ) AS varchar(50)) [EMail],
	[HasForeignNationality],
	CAST(DECRYPTBYKEY( [FirstName] ) AS varchar(50)) [FirstName],
	CAST(DECRYPTBYKEY( [LastName] ) AS varchar(50)) [LastName],
	[BirthDate],	
	[PlaceBirth],
	[GenderId],
	[NationalityId],
	[MaritalStatusId],
	[DocumentTypeId],
	CAST(DECRYPTBYKEY( [DocumentNumber] ) AS varchar(50)) [DocumentNumber],
	[TributeKeyTypeId],
	CAST(DECRYPTBYKEY( [TributeKey] ) AS varchar(50)) [TributeKey],
	[ProfessionId]	
FROM UIFInformationNaturalPersonsEncrypt

GO
/****** Object:  Trigger [dbo].[UIFInformationNaturalPersonsTg]    Script Date: 18/5/2018 15:00:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create TRIGGER [dbo].[UIFInformationNaturalPersonsTg] on [dbo].[UIFInformationNaturalPersons]
INSTEAD OF INSERT
AS
BEGIN
  INSERT INTO [UIFInformationNaturalPersonsEncrypt] (
	[Id],
	[TransactionRequestId],
	[CreationDate],
	[UIFRequestId],
	[UIFRegisterType],
	[UIFTypeUpdateDate],
	[Address1],
	[Address2],
	[ZipCode],
	[LocalityId],
	[ProvinceId],
	[PhoneCountryCode],
	[PhoneProvinceCode],
	[PhoneNumber],
	[EMail],
	[HasForeignNationality],
	[FirstName],
	[LastName],
	[BirthDate],
	[PlaceBirth],
	[GenderId],
	[NationalityId],
	[MaritalStatusId],
	[DocumentTypeId],
	[DocumentNumber],
	[TributeKeyTypeId],
	[TributeKey],
	[ProfessionId]
  )
  SELECT
	[Id],
    [TransactionRequestId],
	[CreationDate],
	[UIFRequestId],
	[UIFRegisterType],
	[UIFTypeUpdateDate],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [Address1] ),
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [Address2] ),
	[ZipCode],
	[LocalityId],
	[ProvinceId],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [PhoneCountryCode] ),
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [PhoneProvinceCode] ),
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [PhoneNumber] ),
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [EMail] ),
	[HasForeignNationality],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [FirstName] ),
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [LastName] ),
	[BirthDate],
	[PlaceBirth],
	[GenderId],
	[NationalityId],
	[MaritalStatusId],
	[DocumentTypeId],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [DocumentNumber] ),
	[TributeKeyTypeId],
	encryptbykey(Key_GUID('CustomerAccessDataKey'), [TributeKey] ),
	[ProfessionId]
  FROM inserted
END;
GO

CREATE TABLE [dbo].[UIFInformationLegalPersonsEncrypt](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[BusinessName] [varbinary](max) NULL,
	[LegalRepresentativeFirstName] [varbinary](max) NULL,
	[LegalRepresentativeLastName] [varbinary](max) NULL,
	[EnrollmentDate] [datetime] NULL,
	[EnrollmentNumber] [int] NULL,
	[ConstitutiveActDate] [datetime] NULL,
	[DocumentNumber] [varbinary](max) NULL,
	[BusinessActivityId] [int] NULL,
	[TransactionRequestId] [bigint] NULL,
	[CreationDate] [datetime] NULL,
	[UIFRequestId] [bigint] NOT NULL,
	[UIFRegisterType] [int] NOT NULL,
	[UIFTypeUpdateDate] [datetime] NULL,
	[Address1] [varbinary](max) NULL,
	[Address2] [varbinary](max) NULL,
	[ZipCode] [varchar](8) NULL,
	[LocalityId] [int] NULL,
	[ProvinceId] [int] NULL,
	[PhoneCountryCode] [varbinary](max) NULL,
	[PhoneProvinceCode] [varbinary](max) NULL,
	[PhoneNumber] [varbinary](max) NULL,
	[EMail] [varbinary](max) NULL,
	[HasForeignNationality] [bit] NULL,
 CONSTRAINT [PK_UIFInformationLegalPersonsEncrypt] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[UIFInformationLegalPersonsEncrypt]  WITH NOCHECK ADD  CONSTRAINT [FK_UIFInformationLegalPersonsEncrypt_BusinessActivities] FOREIGN KEY([BusinessActivityId])
REFERENCES [dbo].[BusinessActivities] ([Id])
GO
ALTER TABLE [dbo].[UIFInformationLegalPersonsEncrypt] CHECK CONSTRAINT [FK_UIFInformationLegalPersonsEncrypt_BusinessActivities]
GO
ALTER TABLE [dbo].[UIFInformationLegalPersonsEncrypt]  WITH NOCHECK ADD  CONSTRAINT [FK_UIFInformationLegalPersonsEncrypt_Localities] FOREIGN KEY([LocalityId])
REFERENCES [dbo].[Localities] ([Id])
GO
ALTER TABLE [dbo].[UIFInformationLegalPersonsEncrypt] CHECK CONSTRAINT [FK_UIFInformationLegalPersonsEncrypt_Localities]
GO
ALTER TABLE [dbo].[UIFInformationLegalPersonsEncrypt]  WITH NOCHECK ADD  CONSTRAINT [FK_UIFInformationLegalPersonsEncrypt_Provinces] FOREIGN KEY([ProvinceId])
REFERENCES [dbo].[Provinces] ([Id])
GO
ALTER TABLE [dbo].[UIFInformationLegalPersonsEncrypt] CHECK CONSTRAINT [FK_UIFInformationLegalPersonsEncrypt_Provinces]
GO
ALTER TABLE [dbo].[UIFInformationLegalPersonsEncrypt]  WITH NOCHECK ADD  CONSTRAINT [FK_UIFInformationLegalPersonsEncrypt_TransactionRequests] FOREIGN KEY([TransactionRequestId])
REFERENCES [dbo].[TransactionRequests] ([Id])
GO
ALTER TABLE [dbo].[UIFInformationLegalPersonsEncrypt] CHECK CONSTRAINT [FK_UIFInformationLegalPersonsEncrypt_TransactionRequests]
GO
ALTER TABLE [dbo].[UIFInformationLegalPersonsEncrypt]  WITH NOCHECK ADD  CONSTRAINT [FK_UIFInformationLegalPersonsEncrypt_UIFInformationLegalPersons] FOREIGN KEY([Id])
REFERENCES [dbo].[UIFInformationLegalPersonsEncrypt] ([Id])
GO
ALTER TABLE [dbo].[UIFInformationLegalPersonsEncrypt] CHECK CONSTRAINT [FK_UIFInformationLegalPersonsEncrypt_UIFInformationLegalPersons]
GO
ALTER TABLE [dbo].[UIFInformationLegalPersonsEncrypt]  WITH NOCHECK ADD  CONSTRAINT [FK_UIFInformationLegalPersonsEncrypt_UIFRequests] FOREIGN KEY([UIFRequestId])
REFERENCES [dbo].[UIFRequests] ([Id])
GO
ALTER TABLE [dbo].[UIFInformationLegalPersonsEncrypt] CHECK CONSTRAINT [FK_UIFInformationLegalPersonsEncrypt_UIFRequests]
GO

CREATE VIEW [dbo].[UIFInformationLegalPersons] AS
SELECT 
	[Id],
	CAST(DECRYPTBYKEY( [BusinessName] ) AS varchar(50)) [BusinessName],
	CAST(DECRYPTBYKEY( [LegalRepresentativeFirstName] ) AS varchar(50)) [LegalRepresentativeFirstName],
	CAST(DECRYPTBYKEY( [LegalRepresentativeLastName] ) AS varchar(50)) [LegalRepresentativeLastName],
	[EnrollmentDate],
	[EnrollmentNumber],
	[ConstitutiveActDate],
	CAST(DECRYPTBYKEY( [DocumentNumber] ) AS varchar(50)) [DocumentNumber],
	[BusinessActivityId],
	[TransactionRequestId],
	[CreationDate],
	[UIFRequestId],
	[UIFRegisterType],
	[UIFTypeUpdateDate],
	CAST(DECRYPTBYKEY( [Address1] ) AS varchar(50)) [Address1],
	CAST(DECRYPTBYKEY( [Address2] ) AS varchar(50)) [Address2],
	[ZipCode],
	[LocalityId],
	[ProvinceId],
	CAST(DECRYPTBYKEY( [PhoneCountryCode] ) AS varchar(50)) [PhoneCountryCode],
	CAST(DECRYPTBYKEY( [PhoneProvinceCode] ) AS varchar(50)) [PhoneProvinceCode],
	CAST(DECRYPTBYKEY( [PhoneNumber] ) AS varchar(50)) [PhoneNumber],
	CAST(DECRYPTBYKEY( [EMail] ) AS varchar(50)) [EMail],
	[HasForeignNationality]
FROM UIFInformationLegalPersonsEncrypt