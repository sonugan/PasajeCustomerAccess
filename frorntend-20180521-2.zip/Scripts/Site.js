﻿var ClientId;
var BaseAddress, myApp;
var loadingModal;

$(function () {
    GetBaseAddress();
    //variable del Modal de carga
    loadingModal = '<div id="loading" class="row"><div class="col-xs-12 text-center"><img id="loading-image" style="width:40px;height:40px;" src="' + BaseAddress + 'Content/img/page-loader.gif" alt="Procesando..." /></div></div>';

    //Maneja el estado activo del menu
    $("#navbar3").find(".active").removeClass("active");
    $('#navbar3').find('a[href="' + location.pathname + '"]').parents('li').addClass('active');

})

function CreateAppAngular() {
    if (myApp == undefined)
        myApp = angular.module('myApp', ['smart-table']);
}

function GetBaseAddress() {
    if (BaseAddress == undefined) {

        BaseAddress = $("#urlHome").text();
    }
}


var AnalyticsEventManager = (function(){
    var me = this

    var sendEvent = function(category, action, label){
        if(ga){
            ga('send', 'event', category, action, label)
        }
    }

    var sendDownloadEvent = function (category, label){
        sendEvent(category, 'Download ' + label, label)
    }

    var sendChangeEvent = function (category, label){
        sendEvent(category, label, label)
    }

    var sendTransactionEvent = function (category, action, label){
        sendEvent(category, action + ' ' + label, label)
    }
    
    return { 
        sendDownloadEvent : sendDownloadEvent,
        sendChangeEvent : sendChangeEvent,
        sendTransactionEvent : sendTransactionEvent
    }
})()


var customSorters = (function(){
    var dateEs = function (a, b) {
        if (a && !b) return 1
        if (b && !a) return -1
        var aParts = a.split('/')
        var bParts = b.split('/')

        if (aParts.length == 3 && bParts.length == 3) {
            if (parseInt(aParts[2]) > parseInt(bParts[2])) return 1
            if (parseInt(aParts[2]) < parseInt(bParts[2])) return -1
            if (parseInt(aParts[2]) == parseInt(bParts[2])) {
                if (parseInt(aParts[1]) > parseInt(bParts[1])) return 1
                if (parseInt(aParts[1]) < parseInt(bParts[1])) return -1
                if (parseInt(aParts[1]) == parseInt(bParts[1])) {
                    if (parseInt(aParts[0]) > parseInt(bParts[0])) return 1
                    if (parseInt(aParts[0]) < parseInt(bParts[0])) return -1
                    return 0
                }
            }
        }
        if (aParts.length == 3 && bParts.length != 3) {
            return 1
        }
        if (aParts.length != 3 && bParts.length == 3) {
            return -1
        }
    }

    return {
        dateEs: dateEs
    }
})()