﻿function initSelects() {

    $.ajax({
        url: BaseAddress + "/DropDown/GetBanks",
        dataType: 'json',
        type: 'GET',
        success: function (data) {

            if (data != null) {
                $.each(data, function (i, item) {
                    $('#FPMCCardBank').append($("<option></option>").attr("value", item.Id).text(item.Description));
                    $('#FPMDDebitBank').append($("<option></option>").attr("value", item.Id).text(item.Description));
                });
            }
        }
    });

    $.ajax({
        url: BaseAddress + "/DropDown/GetCreditCardTypes",
        dataType: 'json',
        type: 'GET',
        success: function (data) {

            if (data != null) {
                $.each(data, function (i, item) {
                    $('#FPMCCardCreditCardType').append($("<option></option>").attr("value", item.Id).text(item.Description));
                });
            }
        }
    });
    
}

var modalFinancialDataRequest = (function () {

    initFinancialDataRequest = function () {

        initComponentsFinancialDataRequest();

    },

    initComponentsFinancialDataRequest = function () {

        $('#FPMDDirectDebitDate').datepicker({
            autoclose: true,
            format: "dd/mm/yyyy",
            forceParse: true
        });

        $('#FPMCCardExpiryDate').datepicker({
            autoclose: true,
            format: "mm/yy",
            minViewMode: 1,
            forceParse: true
        });

        // Boton Modificar.
        $('#btnUpdateFrecuencyPaymentMethods').on('click', function () {

            $('#modalFinancialDataRequest').modal('show');

            //// Muestro el loader.
            //$("#loaderModal").modal('show');

            //// Limpio el modal.
            //cleanHomeAddressModal();

            //// Inicializo el modal.
            //$.ajax({
            //    url: BaseAddress + "/Policies/ChangeAddressRequest?applicationId=" + $('#ApplicationId').val() + "&addressTypeId=1",
            //    dataType: 'json',
            //    type: 'GET',
            //    success: function (data) {

            //        // Oculto el loader.
            //        $("#loaderModal").modal('hide');

            //        // Solo si es nuevo seteo los datos.
            //        if (data.RequestNumber != 0) {
            //            setDataHomeAddressModal(data);
            //        }

            //        // Muestro el modal.
            //        $('#modalHAddress').modal('show');

            //    }
            //});

        });

    }

    cleanCollapseCreditCard = function () {

        // Tipo TC.
        $('#FPMCCardCreditCardType').val(-1);

        // Banco emisor.
        $('#FPMCCardBank').val(-1);

        // Nro. de Tarjeta.
        $('#FPMCCardNumber1').val("");
        $('#FPMCCardNumber2').val("");
        $('#FPMCCardNumber3').val("");
        $('#FPMCCardNumber4').val("");

        // Fecha vencimiento.
        $('#FPMCCardExpiryDate').val("");

        // Código de seguridad.
        $('#FPMCCardSecurityCode').val("");

        // Nombre/s pagador.
        $('#FPMCCardPayerFirstName').val("");

        // Apellido/s pagador.
        $('#FPMCCardPayerLastName').val("");

        // Razón social pagador.
        $('#FPMCCardPayerBusinessName').val("");

    }

    cleanCollapseBankDeposit = function () {

        // Nro. Cuenta.
        $('#FPMDDebitAccountNumber').val("");

        // Banco.
        $('#FPMDDebitBank').val(-1);

        // Sucursal.
        $('#FPMDDebitBankBranch').val("");

        // CBU.
        $('#FPMDDebitCBU').val("");

        // Fecha de débito.
        $('#FPMDDirectDebitDate').val("");

        // Nombre/s pagador.
        $('#FPMDDebitPayerFirstName').val("");

        // Apellido/s pagador.
        $('#FPMDDebitPayerLastName').val("");

        // Razón social pagador.
        $('#FPMDDebitPayerBusinessName').val("");

    }

    cleanCollapseDirectDebit = function () {

    }

    return {
        initFinancialDataRequest: initFinancialDataRequest
    }

})();

var paymentMethodsCollapses = (function () {

    var collapses = [];
    
    paymentMethodsInit = function () {

        collapses.push($('#FPMCollapseCreditCard'));
        collapses.push($('#FPMCollapseBankDeposit'));
        collapses.push($('#FPMCollapseDirectDebit'));

        $('#FPMCollapseBankDeposit').collapse();
        $('#FPMCollapseDirectDebit').collapse();
    },

    paymentMethodsOptionsClick = function (opt) {

        // Si el collapse del option esta abierto, entonces no se realiza ninguna acción.
        if (!$(opt.value).hasClass('in')) {

            $.each(collapses, function (index, item) {

                if (item[0].id == opt.value) {
                    item.collapse('show');
                }
                else {

                    item.collapse('hide');

                    // Limpio el collapse de "Tarjeta de credito".
                    if (item[0].id == "FPMCollapseCreditCard") {
                        cleanCollapseCreditCard();
                    }

                    // Limpio el collapse de "Deposito bancario".
                    if (item[0].id == "FPMCollapseBankDeposit") {
                        cleanCollapseBankDeposit();
                    }

                    // Limpio el collapse de "Débito directo".
                    if (item[0].id == "FPMCollapseDirectDebit") {
                        cleanCollapseDirectDebit();
                    }

                }

            });

        }

    }

    return {
        paymentMethodsOptionsClick: paymentMethodsOptionsClick,
        paymentMethodsInit: paymentMethodsInit
    }

})();

$(document).ready(function () {

    // Inicializo los combos del formulario.
    initSelects();

    // Inicializo el modal para la solicitud de "Datos Financieros".
    modalFinancialDataRequest.initFinancialDataRequest();

    // Inicializo los collapse de "Medio de pago".
    paymentMethodsCollapses.paymentMethodsInit();

});                