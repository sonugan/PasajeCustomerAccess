﻿
var uifRequestsModule = (function(){

    var localities = [];

    function initSelects() {

        getLocalities();
        getProvinces();
        getCountries();
        getTributeKeyTypes();
        getGenders();
        getDocumentTypes();
        getMaritalStatus();
        getProfessions();
        getBusinessActivities();

    }

    // Inicializo el combo Localidades.
    function getProfessions() {

        $.ajax({
            url: BaseAddress + "/DropDown/GetProfessions",
            dataType: 'json',
            type: 'GET',
            success: function (data) {

                if (data != null) {
                    $.each(data, function (i, item) {
                        $('#NPProfession').append($("<option></option>").attr("value", item.Id).text(item.Name));
                    });
                }
            }
        });
    }

    // Inicializo el combo Actividad principal.
    function getBusinessActivities() {

        $.ajax({
            url: BaseAddress + "/DropDown/GetBusinessActivities",
            dataType: 'json',
            type: 'GET',
            success: function (data) {

                if (data != null) {
                    $.each(data, function (i, item) {
                        $('#LPCoreBusiness').append($("<option></option>").attr("value", item.Id).text(item.Name));
                    });
                }
            }
        });
    }

    // Inicializo el combo Localidades.
    function getLocalities() {

        $.ajax({
            url: BaseAddress + "/DropDown/GetLocalities",
            dataType: 'json',
            type: 'GET',
            success: function (data) {

                if (data != null) {
                    localities = data;
                }
            }
        });
    }

    // Inicializo el combo Provincia.
    function getProvinces() {

        $.ajax({
            url: BaseAddress + "/DropDown/GetProvinces",
            dataType: 'json',
            type: 'GET',
            success: function (data) {

                if (data != null) {
                    $.each(data, function (i, item) {
                        $('#NPProvince').append($("<option></option>").attr("value", item.Id).text(item.Name));
                        $('#LPProvince').append($("<option></option>").attr("value", item.Id).text(item.Name));
                    });
                }
            }
        });
    }

    // Inicializo el combo Nacionalidad, y Residencia-Nacionalidad extranjera.
    function getCountries() {

        $.ajax({
            url: BaseAddress + "/DropDown/GetCountries",
            dataType: 'json',
            type: 'GET',
            success: function (data) {

                if (data != null) {

                    $.each(data, function (i, item) {

                        $('#NPNacionality').append($("<option></option>").attr("value", item.Id).text(item.Name));
                        $('#NPForeignNationalities').append($("<option></option>").attr("value", item.Id).text(item.Name));
                        $('#LPForeignNationalities').append($("<option></option>").attr("value", item.Id).text(item.Name));
                    });

                    // Refresco el select multiple para que se vean los options agregados.
                    $('#NPForeignNationalities').selectpicker("refresh");
                    $('#LPForeignNationalities').selectpicker("refresh");
                }

            }
        });

    }

    // Inicializo el combo Tipos de clave tributaria.
    function getTributeKeyTypes() {

        $.ajax({
            url: BaseAddress + "/DropDown/GetTributeKeyTypes",
            dataType: 'json',
            type: 'GET',
            success: function (data) {

                if (data != null) {
                    $.each(data, function (i, item) {
                        $('#NPTributeType').append($("<option></option>").attr("value", item.Id).text(item.Name));
                    });
                }
            }
        });
    }

    // Inicializo el combo de genero sexual.
    function getGenders() {

        $.ajax({
            url: BaseAddress + "/DropDown/GetGenders",
            dataType: 'json',
            type: 'GET',
            success: function (data) {

                if (data != null) {
                    $.each(data, function (i, item) {
                        $('#NPSex').append($("<option></option>").attr("value", item.Id).text(item.Name));
                    });
                }
            }
        });
    }

    // Inicializo el combo de tipos de documentos.
    function getDocumentTypes() {

        $.ajax({
            url: BaseAddress + "/DropDown/GetDocumentTypes",
            dataType: 'json',
            type: 'GET',
            success: function (data) {

                if (data != null) {
                    $.each(data, function (i, item) {
                        $('#NPDocumentType').append($("<option></option>").attr("value", item.Id).text(item.Name));
                    });
                }
            }
        });
    }

    // Inicializo el combo de tipos de estado civil.
    function getMaritalStatus() {

        $.ajax({
            url: BaseAddress + "/DropDown/GetMaritalStatus",
            dataType: 'json',
            type: 'GET',
            success: function (data) {

                if (data != null) {
                    $.each(data, function (i, item) {
                        $('#NPMaritalStatus').append($("<option></option>").attr("value", item.Id).text(item.Name));
                    });
                }
            }
        });
    }

    var client = null;
    var modalUIFNaturalPersonUpdateInformation = (function () {

        init = function () {

            $('#NPBirthDate').datepicker({
                autoclose: true,
                format: "dd/mm/yyyy",
                forceParse: true
            });
            //.on('changeDate', function (ev) {
            //    (ev.viewMode == 'days') ? $(this).datepicker('hide') : '';
            //});

            // Muestro el modal para la actualización de información.
            $('#ModalUIFUpdateNatualPerson').modal('show');

            // Inicializo las validaciones del formulario.
            $('#UIFUpdateNatualPersonForm').validate({
                rules: {
                    UIFUpdateNatualPersonCheckbox: {
                        required: true
                    },
                    NPEMail: {
                        email: true
                    }
                },
                errorPlacement: function (error, element) {

                    // Para el error del checkbox se inserta el label despues del div que contiene el checkbox.
                    if (element.attr("name") == "UIFUpdateNatualPersonCheckbox") {
                        error.insertAfter("#UIFUpdateNatualPersonCheckboxDiv");
                    }
                    else {
                        error.insertAfter(element);
                    }
                },
                messages: {
                    UIFUpdateNatualPersonCheckbox: "Debe confirmar que ha leído los términos y condiciones",
                    NPEMail: "Debe ingresar un email válido"
                }
            });

            // Botón "Actualizar datos".
            $('#UIFUpdateNatualPersonUpdate').on('click', function (e) {

                // Debe aceptar los terminos y condiciones.
                if ($("#UIFUpdateNatualPersonForm").valid()) {

                    // Selección de las nacionalidades extranjeras.
                    var NPForeignNationalitiesIds = [];
                    var NPForeignNationalitiesSelected = $("#NPForeignNationalities").val();
                    if (NPForeignNationalitiesSelected != null) {

                        $.each(NPForeignNationalitiesSelected, function (index, item) {
                            NPForeignNationalitiesIds.push(item);
                        });
                    }

                    $.ajax({
                        url: BaseAddress + "UIFRequest/UpdateNatualPerson",
                        data: {
                            ClientId: client.ClientId,
                            FirstName: $('#NPFirstName').val(),
                            LastName: $('#NPLastName').val(),
                            BirthDate: $('#NPBirthDate').val(),
                            GenderId: $('#NPSex').val(),
                            PlaceBirth: $('#NPPlaceBirth').val(),
                            NacionalityId: $('#NPNacionality').val(),
                            DocumentTypeId: $('#NPDocumentType').val(),
                            DocumentNumber: $('#NPDocumentNumber').val(),
                            TributeKeyTypeId: $('#NPTributeType').val(),
                            TributeKey: $('#NPTributeKey').val(),
                            MaritalStatusId: $('#NPMaritalStatus').val(),
                            Address1: $('#NPAddress1').val(),
                            Address2: $('#NPAddress2').val(),
                            ZipCode: $('#NPZipCode').val(),
                            LocalityId: $('#NPLocality').val(),
                            ProvinceId: $('#NPProvince').val(),
                            PhoneCountryCode: $('#NPPhoneCountryCode').val(),
                            PhoneProvinceCode: $('#NPPhoneProvinceCode').val(),
                            PhoneNumber: $('#NPPhoneNumber').val(),
                            EMail: $('#NPEMail').val(),
                            ProfessionId: $('#NPProfession').val(),
                            ForeignNationalityIds: NPForeignNationalitiesIds
                        },
                        dataType: 'json',
                        type: 'POST',
                        beforeSend: function () {
                            $('#loaderModal').modal('show');
                        },
                        success: function (result) {

                            $('#loaderModal').modal('hide');

                            if (result.Success) {

                                $("#modalInfoText").empty();
                                $("#modalInfoText").append("Nro. de gestión asignado " + result.Data + ".");
                                $("#modalInfo").modal({
                                    keyboard: false
                                });

                                $('#ModalUIFUpdateNatualPerson').modal('hide');
                                showUifRequestMenu(false)
                            }
                            else {

                                $("#modalInfoText").empty();
                                $("#modalInfoText").append("No se pudo actualizar la información.");
                                $("#modalInfo").modal({
                                    backdrop: 'static',
                                    keyboard: false
                                });

                            }

                        },
                        error: function (xhr, ajaxOptions, thrownError) {

                            $('#loaderModal').modal('hide');

                            $("#modalInfoText").empty();
                            $("#modalInfoText").append("No se pudo actualizar la información.");
                            $("#modalInfo").modal({
                                backdrop: 'static',
                                keyboard: false
                            });
                        }

                    });

                }

            });

            // Nacionalidad extranjera.
            $('input[type=radio][name=NPForeignNationalitiesOpt]').change(function (e) {

                // Si tiene nacionalidad extranjera.
                //if ($('#NPForeignNationalitiesOptYes').prop('checked')) {
                if (this.id == "NPForeignNationalitiesOptYes"){

                    $('#NPForeignNationalities').prop('disabled', false);
                }
                else {

                    $('#NPForeignNationalities').prop('disabled', true);
                    $('#NPForeignNationalities').val([]);
                }

                $('#NPForeignNationalities').selectpicker("refresh");

            });

            // Change del select provincia para llenar el select de localidades.
            $('#NPProvince').change(function (e) {

                // Limpio el select de localidades.
                $('#NPLocality').empty()
                    .append($('<option selected="selected"></option>').attr("value", -1).text(" -- Seleccione -- "));

                // Si no selecciono ninguna provincia.
                var provinceId = parseInt(this.value);
                if (provinceId == -1) {

                    // Deshabilito el combo de localidades.
                    $('#NPLocality').prop('disabled', true);

                }
                else {

                    // Agrego todas las localidades que pertenecen a la provincia seleccionada.
                    $.each(localities, function (i, item) {

                        if (item.ProvinceId == provinceId) {
                            $('#NPLocality').append($("<option></option>").attr("value", item.Id).text(item.Name));
                        }

                    });

                    // Habilito el combo de localidades.
                    $('#NPLocality').prop('disabled', false);

                }

            });

        };

        return {
            init: init
        }

    })();

    var modalUIFLegalPersonUpdateInformation = (function () {
        
        init = function () {

            $('#LPEnrollmentDate').datepicker({
                autoclose: true,
                format: "dd/mm/yyyy",
                forceParse: true
            });

            $('#LPConstitutiveActDate').datepicker({
                autoclose: true,
                format: "dd/mm/yyyy",
                forceParse: true
            });

            // Muestro el modal para la actualización de información.
            $('#ModalUIFUpdateLegalPerson').modal('show');

            // Inicializo las validaciones del formulario.
            $('#UIFUpdateLegalPersonForm').validate({
                rules: {
                    UIFUpdateLPCheckbox: {
                        required: true
                    },
                    LPEMail: {
                        email: true
                    }
                },
                errorPlacement: function (error, element) {

                    // Para el error del checkbox se inserta el label despues del div que contiene el checkbox.
                    if (element.attr("name") == "UIFUpdateLPCheckbox") {
                        error.insertAfter("#UIFUpdateLPCheckboxDiv");
                    }
                    else {
                        error.insertAfter(element);
                    }
                },
                messages: {
                    UIFUpdateLPCheckbox: "Debe confirmar que ha leído los términos y condiciones",
                    LPEMail: "Debe ingresar un email válido"
                }
            });

            // Botón "Actualizar datos".
            $('#UIFUpdateLPBtnUpdate').on('click', function (e) {

                // Debe aceptar los terminos y condiciones.
                if ($("#UIFUpdateLegalPersonForm").valid()) {

                    // Selección de las nacionalidades extranjeras.
                    var LPForeignNationalitiesIds = [];
                    var LPForeignNationalitiesSelected = $("#LPForeignNationalities").val();
                    if (LPForeignNationalitiesSelected != null) {

                        $.each(LPForeignNationalitiesSelected, function (index, item) {
                            LPForeignNationalitiesIds.push(item);
                        });
                    }

                    $.ajax({
                        url: BaseAddress + "UIFRequest/UpdateLegalPerson",
                        data: {
                            ClientId: client.ClientId,
                            BusinessName: $('#LPBusinessName').val(),
                            EnrollmentDate: $('#LPEnrollmentDate').val(),
                            EnrollmentNumber: $('#LPEnrollmentNumber').val(),
                            DocumentNumber: $('#LPDocumentNumber').val(),
                            ConstitutiveActDate: $('#LPConstitutiveActDate').val(),
                            Address1: $('#LPAddress1').val(),
                            Address2: $('#LPAddress2').val(),
                            ProvinceId: $('#LPProvince').val(),
                            LocalityId: $('#LPLocality').val(),
                            ZipCode: $('#LPZipCode').val(),
                            PhoneCountryCode: $('#LPPhoneCountryCode').val(),
                            PhoneProvinceCode: $('#LPPhoneProvinceCode').val(),
                            PhoneNumber: $('#LPPhoneNumber').val(),
                            EMail: $('#LPEMail').val(),
                            BusinessActivityId: $('#LPCoreBusiness').val(),
                            LegalRepresentativeFirstName: $('#LPLegalRepresentativeFirstName').val(),
                            LegalRepresentativeLastName: $('#LPLegalRepresentativeLastName').val(),
                            ForeignNationalityIds: LPForeignNationalitiesIds
                        },
                        dataType: 'json',
                        type: 'POST',
                        beforeSend: function () {
                            $('#loaderModal').modal('show');
                        },
                        success: function (result) {

                            $('#loaderModal').modal('hide');

                            if (result.Success) {

                                $("#modalInfoText").empty();
                                $("#modalInfoText").append("Nro. de gestión asignado " + result.Data + ".");
                                $("#modalInfo").modal({
                                    keyboard: false
                                });

                                $('#ModalUIFUpdateLegalPerson').modal('hide');
                                showUifRequestMenu(false)
                            }
                            else {

                                $("#modalInfoText").empty();
                                $("#modalInfoText").append("No se pudo actualizar la información.");
                                $("#modalInfo").modal({
                                    backdrop: 'static',
                                    keyboard: false
                                });

                            }

                        },
                        error: function (xhr, ajaxOptions, thrownError) {

                            $('#loaderModal').modal('hide');

                            $("#modalInfoText").empty();
                            $("#modalInfoText").append("No se pudo actualizar la información.");
                            $("#modalInfo").modal({
                                backdrop: 'static',
                                keyboard: false
                            });
                        }

                    });

                }

            });

            // Nacionalidad extranjera.
            $('input[type=radio][name=LPForeignNationalitiesOpt]').change(function (e) {

                // Si tiene nacionalidad extranjera.
                if (this.id == "LPForeignNationalitiesOptYes") {

                    $('#LPForeignNationalities').prop('disabled', false);
                }
                else {

                    $('#LPForeignNationalities').prop('disabled', true);
                    $('#LPForeignNationalities').val([]);
                }

                $('#LPForeignNationalities').selectpicker("refresh");

            });

            // Change del select provincia para llenar el select de localidades.
            $('#LPProvince').change(function (e) {

                // Limpio el select de localidades.
                $('#LPLocality').empty()
                    .append($('<option selected="selected"></option>').attr("value", -1).text(" -- Seleccione -- "));

                // Si no selecciono ninguna provincia.
                var provinceId = parseInt(this.value);
                if (provinceId == -1) {

                    // Deshabilito el combo de localidades.
                    $('#LPLocality').prop('disabled', true);

                }
                else {

                    // Agrego todas las localidades que pertenecen a la provincia seleccionada.
                    $.each(localities, function (i, item) {

                        if (item.ProvinceId == provinceId) {
                            $('#LPLocality').append($("<option></option>").attr("value", item.Id).text(item.Name));
                        }

                    });

                    // Habilito el combo de localidades.
                    $('#LPLocality').prop('disabled', false);

                }

            });

        }

        return {
            init: init
        }

    })();

    var showUifRequestMenu = function(show){
        if(show){
            $(".uif-visualization--data-menu").show()
        }else{
            $(".uif-visualization--data-menu").hide()
        }
    }

    var modalUIFLastInformation = (function () {

        init = function (force) {
            caSpinnerModule.initBlock();
            $.ajax({
                url: BaseAddress + "UIFRequest/GetUIFRequest",
                dataType: 'json',
                type: 'GET',
                success: function (result) {

                    if (result.Success) {
                        showUifRequestMenu(result.Data != null)
                        // Si el cliente tiene que completar el formulario se lo muestro.
                        if ((result.Data != null && hasToShow()) || force) {
                            
                            $('#UIFActualDataTBody').empty();

                            // Si es persona jurídica.
                            if (result.Data.IsLegalPerson) {

                                var rows = '<tr><td class="col-sm-6 col-md-6 col-lg-6">DENOMINACION O RAZÓN SOCIAL</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.BusinessName + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">FECHA DE INSCRIPCIÓN REGISTRAL</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.EnrollmentDate + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">NRO. DE INSCRIPCIÓN REGISTRAL</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.EnrollmentNumber + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">CUIT / CDI</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.DocumentNumber + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">FECHA DE ESCRITURA CONSTITUTIVA O FECHA DEL CONTRATO</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.ContractDate + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">DOMICILIO LEGAL</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.Address + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">CÓDIGO POSTAL</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.ZipCode + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">LOCALIDAD</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.Locality + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">PROVINCIA</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.Province + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">TELÉFONO DE LA SEDE SOCIAL</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.Phone + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">MAIL</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.EMail + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">NOMBRE y APELLIDO REPRESENTANTE LEGAL, APODERADO</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.LegalRepresentative + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">TIENE CIUDADANIA Y/O RESIDENCIA EN UN PAÍS QUE NO SEA LA REPÚBLICA ARGENTINA</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.HasForeignNationality + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">CIUDADANIAS Y/O RESIDENCIAS</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.ForeignNationalities + '</td></tr>';

                                $('#UIFActualDataTBody').append(rows);
                            }
                            else {

                                // Si es persona Natural.
                                var rows = '<tr><td class="col-sm-6 col-md-6 col-lg-6">NOMBRE</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.FirstName + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">APELLIDO</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.LastName + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">FECHA DE NACIMIENTO</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.BirthDate + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">LUGAR DE NACIMIENTO</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.PlaceBirth + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">SEXO</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.Sex + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">NACIONALIDAD</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.Nacionality + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">ESTADO CIVIL</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.MaritalStatus + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">DOCUMENTO</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.DocumentType + ' ' + result.Data.DocumentNumber + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">CLAVE TRIBUTARIA</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.TributeKeyType + ' ' + result.Data.TributeKey + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">DOMICILIO PARTICULAR</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.Address + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">LOCALIDAD</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.Locality + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">TELEFONO</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.Phone + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">MAIL</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.EMail + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">PROFESION/OFICIO/INDUSTRIA/ACT. PRINCIPAL QUE REALICE</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.ProfessionalActivity + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">TIENE CIUDADANIA Y/O RESIDENCIA EN UN PAÍS QUE NO SEA LA REPÚBLICA ARGENTINA</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.HasForeignNationality + '</td></tr>' +
                                    '<tr><td class="col-sm-6 col-md-6 col-lg-6">CIUDADANIAS Y/O RESIDENCIAS</td><td class="col-sm-6 col-md-6 col-lg-6">' + result.Data.ForeignNationalities + '</td></tr>';

                                $('#UIFActualDataTBody').append(rows);
                            }

                            // Asigno el cliente.
                            client = result.Data;
                            // Muestro el modal.
                            $('#ModalUIFLastInformation').modal('show');

                        }

                        caSpinnerModule.hideBlock()

                    }
                    else {
                        caSpinnerModule.hideBlock()
                        bootbox.alert("Error al intentar obtener la información personal.");
                    }
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    caSpinnerModule.hideBlock()
                    bootbox.alert("Error al intentar obtener la información personal.");
                }

            });

            // Inicializo las validaciones del formulario.
            $('#UIFLastPInformationForm').validate({
                rules: {
                    UIFLastPInformationCheckbox: {
                        required: true
                    }
                },
                errorPlacement: function (error, element) {

                    // Para el error del checkbox se inserta el label despues del div que contiene el checkbox.
                    if (element.attr("name") == "UIFLastPInformationCheckbox") {
                        error.insertAfter("#UIFLastPInformationCheckboxDiv");
                    }
                    else {
                        error.insertAfter(element);
                    }
                },
                messages: {
                    UIFLastPInformationCheckbox: "Debe confirmar que ha leído los términos y condiciones"
                }
            });

            // Botón "Confirmar Datos".
            $('#modalConfirmBtnOk').on('click', function (e) {

                $.ajax({
                    url: BaseAddress + "UIFRequest/PostConfirmInformationPersonal",
                    data: {
                        clientId: client.ClientId
                    },
                    dataType: 'json',
                    type: 'POST',
                    beforeSend: function () {
                        $('#loaderModal').modal('show');
                    },
                    success: function (result) {

                        $('#loaderModal').modal('hide');

                        if (result.Success) {

                            $("#modalInfoText").empty();
                            $("#modalInfoText").append("Nro. de gestión asignado " + result.Data + ".");
                            $("#modalInfo").modal({
                                keyboard: false
                            });

                            $('#ModalUIFLastInformation').modal('hide');
                            showUifRequestMenu(false)
                        }
                        else {

                            $("#modalInfoText").empty();
                            $("#modalInfoText").append("No se pudo actualizar la información.");
                            $("#modalInfo").modal({
                                backdrop: 'static',
                                keyboard: false
                            });

                        }

                    },
                    error: function (xhr, ajaxOptions, thrownError) {

                        $('#loaderModal').modal('hide');

                        $("#modalInfoText").empty();
                        $("#modalInfoText").append("No se pudo actualizar la información.");
                        $("#modalInfo").modal({
                            backdrop: 'static',
                            keyboard: false
                        });
                    }

                });

            });

            // Botón "Confirmar Datos".
            $('#btnUIFModalConfirm').on('click', function (e) {

                // Debe aceptar los terminos y condiciones.
                if ($("#UIFLastPInformationForm").valid()) {

                    $('#modalConfirm').modal('show');

                }

            });

            // Botón "Actualizar Datos".
            $('#btnUIFModalUpdateData').on('click', function (e) {

                // Oculto el modal de la ultima información.
                $('#ModalUIFLastInformation').modal('hide');

                // Si es persona juridica.
                if (client.IsLegalPerson) {

                    modalUIFLegalPersonUpdateInformation.init();
                }
                else {

                    modalUIFNaturalPersonUpdateInformation.init();
                }

            });

        };

        var hasToShow = function(){
            var validLocations = [caPageModuleUtils.Root, 'Policies/Policies']

            return !uifInformationRequestModalHasBeenShow && validLocations.reduce(function(previous,current, i, list){
                return previous || (BaseAddress + current) == caPageModuleUtils.currentLocation()
            }, false)
        }

        
        return {
            init: init
        };

    })();

    return {
        showLastUifInformation: function(force){
            if(ClientId){
                modalUIFLastInformation.init(force);
                
                // Inicializo los combos de formluario UIF.
                initSelects();

                $('.modal').on('hidden.bs.modal', function (e) {
                    if ($('.modal').hasClass('in')) {
                        $('body').addClass('modal-open');
                    }
                });
            }
        }
    }
})()

$(document).ready(function () {
    uifRequestsModule.showLastUifInformation(false)
});

var caPageModuleUtils = (function () {
    return {
        isRootPage: function () {
            return BaseAddress == window.location.href
        },
        currentLocation: function () {
            return window.location.href
        }
    }
})();

var caSpinnerModule = (function () {
    return {
        initBlock: function () {
            $("#loaderModal").modal('show');
        },
        hideBlock: function () {
            $("#loaderModal").modal('hide');
        }
    }
})()
