﻿
// Array de los datos de la grilla.
var transactionsList = [];

var transactionModule = (
    function () {
        init = function () {
            getTransactions()
            $("#findTransactions").on('click', function () {
                getTransactions(1);
            });
        },

        getTransactions = function (page, sortConfig) {
            const pageSize = 10

            var applicationIds = [];
            var transactionTypesIds = [];

            // Selección de los tipos de transacción.
            var transactionTypeSelected = $("#selectTransactionType").val();
            if (transactionTypeSelected != null) {

                $.each(transactionTypeSelected, function (index, item) {
                    transactionTypesIds.push(item);
                });
            }
            else {

                var options = $("#selectTransactionType").find('option');
                $.each(options, function (index, item) {
                    transactionTypesIds.push(item.value);
                });
            }

            // Selección de las pólizas.
            var policiesSelected = $("#selectPolicies").val();
            if (policiesSelected != null) {

                $.each(policiesSelected, function (index, item) {
                    applicationIds.push(item);
                });
            }
            else {

                var options = $("#selectPolicies").find('option');
                $.each(options, function (index, item) {
                    applicationIds.push(item.value);
                });
            }

            let filters = {
                ApplicationIds: applicationIds,
                TransactionTypesIds: transactionTypesIds,
                PageSize: pageSize,
                PageNumber: page? page : 1,
                SortField: sortConfig ? sortConfig.SortField : null,
                SortDirection: sortConfig ? sortConfig.SortDirection : null
            }

            // Muestro el loader.
            $("#loaderModal").modal('show');

            // Limpio la tabla.
            $('#TRequestsTableBody').empty();
            
            $.ajax({
                url: BaseAddress + "Transaction/GetTransactionRequests",
                data: { filter: filters },
                dataType: 'json',
                type: 'POST',
                success: function (result) {
                    // Oculto el loader.
                    $("#loaderModal").modal('hide');

                    if (result.Data && result.Data.Rows) {
                        // Asigno la lista a la variable.
                        transactionsList = result.Data.Rows

                        $.each(result.Data.Rows, function (index, item) {
                            var row = '<tr class="text-center">' +
                                            '<td>' + item.TransactionNumber + '</td>' +
                                            (item.TransactionChangeRequestTypeId == 10 ?
                                                '<td><button class="glyphicon glyphicon-info-sign" onclick="transactionModule.showDocumments(' + item.TransactionNumber + ',&quot;' + item.PolicyNumber + '&quot;);"></button></td>'
                                            : '<td>' + item.PolicyNumber + '</td>') +
                                            '<td>' + item.TransactionChangeRequestType + '</td>' +
                                            '<td>' + item.RequestDate + '</td>' +
                                            '<td>' + item.VtimeState + '</td>' +
                                            '<td><button class="glyphicon glyphicon-search" onclick="transactionModule.showModalDetail(' + item.TransactionNumber + ',&quot;' + item.PolicyNumber + '&quot;);"></button></td>'
                            '</tr>';

                            $('#TRequestsTableBody').append(row);

                        });

                        //$('#tableTrabsactions').trigger('footable_initialize');

                        caPaginateModule.fillPages(result.Data.PageCount, page)
                        //$('#TRequestsTableBody').empty()
                    }

                },
                error: function (xhr, ajaxOptions, thrownError) {

                    // Oculto el loader.
                    $("#loaderModal").modal('hide');

                    bootbox.alert("Error al intentar obtener las transacciones.");
                }

            });

        }

        showModalDetail = function (transactionNumber, policyNumber) {

            var data = {};
            $.each(transactionsList, function (index, item) {

                if (transactionNumber == item.TransactionNumber) {
                    data = item;
                    return;
                }

            });

            // Muestro el modal dependiendo del tipo.
            switch (data.TransactionChangeRequestTypeId) {

                // Dirección Particular, Dirección Legal y Dirección Correspondencia
                case 1:
                case 2:
                case 3:

                    $('#modalAddressStreet').html(data.Address);
                    $('#modalAddressFloor').html(data.Floor);
                    $('#modalAddressApartment').html(data.Apartment);
                    $('#modalAddressLocality').html(data.Locality);
                    $('#modalAddressZipCode').html(data.ZipCode);
                    $('#modalAddressProvince').html(data.Province);
                    $('#modalAddressCountry').html(data.Country);

                    if (data.TransactionChangeRequestType == 1) {

                        // Dirección Particular.
                        $('#modalAddressTitle').html("Dirección Particular");

                    }
                    else if (data.TransactionChangeRequestType == 2) {

                        $('#modalAddressTitle').html("Dirección Legal");
                        // Dirección Legal.

                    }
                    else {

                        // Dirección Correspondencia.
                        $('#modalAddressTitle').html("Dirección Correspondencia");
                        ShowPolicesGroupTransaction(data);
                    }



                    // Muestro el modal.
                    $('#modalAddress').modal('show');

                    break;

                    // Teléfono Particular, Teléfono Celular y Teléfono Laboral.
                case 4:
                case 5:
                case 6:

                    $('#modalPhonesCountryCode').html(data.CountryCodeNumber);
                    $('#modalPhonesProvinceCode').html(data.ProvinceCodeNumber);
                    $('#modalPhonesNumber').html(data.Number);
                    $('#modalPhonesInternalNumberRow').hide();

                    if (data.TransactionChangeRequestType == 4) {

                        // Dirección Teléfono.
                        $('#modalPhonesTitle').html("Teléfono Particular");
                    }
                    else if (data.TransactionChangeRequestType == 5) {

                        // Dirección Celular.
                        $('#modalPhonesTitle').html("Teléfono Celular");
                    }
                    else {

                        // Dirección Laboral.
                        $('#modalPhonesTitle').html("Teléfono Laboral");
                        $('#modalPhonesInternalNumber').html(data.InternalNumber);
                        $('#modalPhonesInternalNumberRow').show();
                    }

                    // Muestro el modal.
                    $('#modalPhones').modal('show');

                    break;

                    // Teléfono Email
                case 7:

                    $('#modalEmailsEmail').html(data.Email);

                    // Muestro el modal.
                    $('#modalEmails').modal('show');

                    break;

                    // Aceptación de documentación
                case 8:

                    // Limpio todo el contenido de la grilla.
                    $('#tBodyDocumentPendingSignature').empty();

                    for (var i = 0; i < data.Documents.length; i++) {

                        var item = '<tr><td>' + data.Documents[i].DocumentType + '</td>' +
                                '<td>' + data.Documents[i].DocumentName + '</td>' +
                                '<td>' + data.Documents[i].DestinationContent + '</td>' +
                                '<td>' + data.Documents[i].SignatureOnlineStatus + '</td>' +
                                '<td>' + data.Documents[i].SignatureOnlineDate + '</td>' +
                                '<td>' + data.Documents[i].SignatureOnlineUser + '</td>' +
                                '<td>' + data.Documents[i].SignatureInPersonStatus + '</td>' +
                                '<td>' + data.Documents[i].SignatureInPersonDate + '</td>' +
                                '<td>' + data.Documents[i].SignatureInPersonUser + '</td></tr>';

                        $('#modalDocumentPendingSignatureTitle').html("Aceptación de documentación - Póliza Nro.: " + policyNumber + " - Transacción Nro.: " + transactionNumber);

                        $('#tBodyDocumentPendingSignature').append(item);

                    }

                    $('#modalDocumentPendingSignature').modal('show');

                    break;

                case 10:
                    showTransactionDetails(data)
                    break;
            }

        }

        function ShowPolicesGroupTransaction(data) {
            if (data.Polices != null && data.Polices.length > 0) {
                $("#policesAddressC").empty();
                var polices = "<h5>Pólizas</h5><p>";
                polices += data.Polices.join(", ");
                polices += "</p>";

                $("#policesAddressC").html(polices);
            } else {
                $("#policesAddressC").empty();
            }
        }

        function NationalityChange(nationality1, nationality2) {
            this.oldNationality = nationality1
            this.currentNationality = nationality2
        }

        function Person(data) {
            this.data = data

            this.hasData = function () {
                return data
            }

            this.isNaturalPerson = function () {
                return this.hasData() &&
                    this.data.PreviusData &&
                    this.data.PreviusData.FirstName
            }

            this.isLegalPerson = function () {
                return this.hasData() &&
                    !this.isNaturalPerson()
            }

            this.hasChanges = function () {
                return this.hasData() &&
                    this.data.Changes
            }

            this.previousData = function () {
                return this.data.PreviusData
            }

            this.changes = function () {
                return this.data.Changes
            }
        }

        let getForeignNationalitiesChanges = function (person) {
            let nationalitiesChanges = []
            $.each(person.OriginalData.ForeignNationalities, function (i, n) {
                if (person.UpdatedData && person.UpdatedData.ForeignNationalities.filter(function (prev) { return prev.Country.Id == n.Country.Id }).length) {
                    nationalitiesChanges.push(new NationalityChange(n, n))
                } else {
                    nationalitiesChanges.push(new NationalityChange(n, null))
                }
            })
            if (person.UpdatedData) {
                $.each(person.UpdatedData.ForeignNationalities, function (i, n) {
                    if (person.OriginalData.ForeignNationalities.filter(function (prev) { return prev.Country.Id == n.Country.Id }).length == 0) {
                        nationalitiesChanges.push(new NationalityChange(null, n))
                    }
                })
            }
            return nationalitiesChanges
        }

        let showTransactionDetails = function (row) {
            
            let person = row
            if (person.PersonType == 'Fisica') {
                $("#modalNaturalPersonalInformationUpdateTitle").html("Datos Persona Física")
                fillNaturalPersonData(person.OriginalData, "PreviusData")
                if (person.UpdatedData) {
                    $(".changes").show()
                    fillNaturalPersonData(person.UpdatedData, "Changes")
                    $("#modalNaturalPersonalInformationUpdatePreviusData").html('Datos Anteriores')
                } else {
                    $(".changes").hide()
                    $("#modalNaturalPersonalInformationUpdatePreviusData").html('Datos')
                }
                $('#modalNaturalPersonalInformationUpdate').modal('show')
            } else {
                fillLegalPersonData(person.OriginalData, "PJPreviusDataLegal")
                if (person.UpdatedData) {
                    fillLegalPersonData(person.UpdatedData, "PJChangesLegal")
                    $(".changes").show()
                } else {
                    $(".changes").hide()
                }
                $('#modalLegalPersonalInformationUpdate').modal('show')
            }
        }
        
        let fillNaturalPersonData = function (person, prefix) {
            if (!person) {
                return
            }
            $("#" + prefix + "FirstName").html(person.FirstName)
            $("#" + prefix + "LastName").html(person.LastName)
            $("#" + prefix + "BirthDate").html(person.BirthDate)
            $("#" + prefix + "PlaceBirth").html(person.PlaceBirth)
            $("#" + prefix + "Gender").html(person.Gender)
            $("#" + prefix + "Nationality").html(person.Nacionality)
            $("#" + prefix + "MaritalStatus").html(person.MaritalStatus)
            $("#" + prefix + "Document").html(person.DocumentType + " " + (person.DocumentNumber? person.DocumentNumber : ""))
            $("#" + prefix + "TributeKey").html(person.TributeKeyType + " " + (person.TributeKey? person.TributeKey : ""))
            $("#" + prefix + "Profesion").html(person.ProfessionalActivity)
            $("#" + prefix + "Address1").html(person.Address1)
            $("#" + prefix + "Address2").html(person.Address2)
            $("#" + prefix + "Province").html(person.Province)
            $("#" + prefix + "Locality").html(person.Locality)
            $("#" + prefix + "ZipCode").html(person.ZipCode)                       
            $("#" + prefix + "PhoneNumber").html(person.PhoneNumber)
            $("#" + prefix + "EMail").html(person.Email)
            $("#" + prefix + "ForeignNationality").html((person.HasForeignNationality ? "Sí" : "No"))

            $("#" + prefix + "ForeignNationality").html(person.ForeignNationality)                
            $("#" + prefix + "ForeignNationalities").html(person.ForeignNationalities) 
        }

        function NationalityChange(nationality1, nationality2) {
            this.oldNationality = nationality1
            this.currentNationality = nationality2
        }

        let fillLegalPersonData = function (person, prefix) {
            $("#" + prefix + "BusinessName").html(person.BusinessName)

            $("#" + prefix + "BirthDate").html(person.BirthDate)
            
            $("#" + prefix + "EnrollmentDate").html(person.EnrollmentDate)
            
            $("#" + prefix + "EnrollmentNumber").html(person.EnrollmentNumber)
            $("#" + prefix + "TributeKey").html(person.DocumentNumber)


            $("#" + prefix + "ConstitutiveActDate").html(person.ConstitutiveActDate)

            $("#" + prefix + "Address1").html(person.Address1)
            $("#" + prefix + "Address2").html(person.Address2)
            $("#" + prefix + "ZipCode").html(person.ZipCode)
            $("#" + prefix + "Locality").html(person.Locality)
            $("#" + prefix + "Province").html(person.Province)

            $("#" + prefix + "PhoneNumber").html(person.PhoneNumber)

            $("#" + prefix + "EMail").html(person.Email)
            $("#" + prefix + "BussinessActivity").html(person.BussinessActivity)
            $("#" + prefix + "LegalRepresentativeFirstName").html(person.LegalRepresentativeFirstName)
            $("#" + prefix + "LegalRepresentativeLastName").html(person.LegalRepresentativeLastName)

            $("#" + prefix + "ForeignNationality").html((person.HasForeignNationality ? "Sí" : "No"))                          
            $("#" + prefix + "ForeignNationalities").html(person.ForeignNationalities) 
        }

        let showDocumments = function (transactionNumber) {
            $('#tBodyRapDocumentsList').empty();
            var data = {};
            $.each(transactionsList, function (index, item) {

                if (transactionNumber == item.TransactionNumber) {
                    data = item;
                    return;
                }

            });

            if (data.OriginalData.RapDocumments) {
                $.each(data.OriginalData.RapDocumments, function (i, nc) {
                    $("#tBodyRapDocumentsList")
                        .append(
                            '<tr>\
                                    <td>' + nc.PolicyNumber + '</td>\
                                    <td>' + nc.FileName + '</td>\
                                </tr>')
                })
            }

            $('#modalRapDocumentsList').modal('show')
        }

        return {
            init: init,
            showModalDetail: showModalDetail,
            showDocumments: showDocumments,
            getTransactions: getTransactions
        }
    })();


$(document).ready(function () {

    transactionModule.init();

    //$("#tableTrabsactions").footable();

    // $(".footable-page-arrow").hide()
    // $(".footable-page").hide()

});


var caPaginateModule = (function(){
    const maxPageShow = 9
    const maxJump = 5
    const moveToFront = '<<'
    const moveToTail = '>>'
    const moveBack = '<'
    const moveForward = '>'

    let currentPage = 1
    let pageSize = 1

    let sortConfig = {
        SortDirection: 'desc'
    }

    let fillPages = function (pageCount, page) {
        if(pageCount){
            pageSize = pageCount
        }else{
            pageCount = pageSize
        }
        if(page){
            currentPage = page
        }
        $(".pagination").empty()
        let to = 0
        let from = 0
        if (pageCount <= maxPageShow) {
            from = 1
            to = pageCount
        } else if (pageCount > maxPageShow) {
            from = currentPage
            to = from + Math.min(maxPageShow, pageCount - from)

            if (to - from < Math.min(maxPageShow, pageCount)) {
                from = from - (Math.min(maxPageShow, pageCount) - (to - from))
            }
        }

        if (from > maxJump) {
            $(".pagination").append('<li><a id="'+ moveToFront + '" href="javascript: void(0);" onclick="caPaginateModule.selectPage(\'' + moveToFront + '\')">' + moveToFront + '</a></li>')
        }
        if (from > 1) {
            $(".pagination").append('<li><a id="'+ moveBack + '" href="javascript: void(0);" onclick="caPaginateModule.selectPage(\'' + moveBack + '\')">' + moveBack + '</a></li>')
        }

        for (let i = from; i <= to; i++) {
            if(currentPage == i){
                $(".pagination").append('<li class="active"><a id="'+ i + '" href="javascript: void(0);" onclick="caPaginateModule.selectPage(' + i + ')">' + i + '</a></li>')
            }else{
                $(".pagination").append('<li><a id="'+ i + '" href="javascript: void(0);" onclick="caPaginateModule.selectPage(' + i + ')">' + i + '</a></li>')
            }
        }

        if (to < pageCount) {
            $(".pagination").append('<li><a id="'+ moveForward + '" href="javascript: void(0);" onclick="caPaginateModule.selectPage(\'' + moveForward + '\')">' + moveForward + '</a></li>')
            if (pageCount - to > maxJump) {
                $(".pagination").append('<li><a id="'+ moveToTail + '" href="javascript: void(0);" onclick="caPaginateModule.selectPage(\'' + moveToTail + '\')">' + moveToTail + '</a></li>')
            }
        }
    }

    let selectPage = function (page) {
        switch (page) {
            case moveForward:
                currentPage = currentPage + 1
                break
            case moveToTail:
                currentPage = currentPage
                break
            case moveBack:
                currentPage = currentPage - 1
                break
            case moveToFront:
                currentPage = 1
                break
            default:
                currentPage = page
                break
        }
        transactionModule.getTransactions(currentPage, sortConfig)
    }

    let resetAllSortIndicators = function(){
        $('.column-sortable')
            .children()
            .remove('.column-sort-indicator')
            .remove('.column-no-sort-indicator')
        $('.column-sortable').append('<span class="column-no-sort-indicator"></span>')
    }

    let sort = function(e){
        resetAllSortIndicators()
        if($(e).hasClass('column-sorted')){
            $(e).removeClass('column-sorted')
            $(e).addClass('column-sorted-desc')
            sortConfig.SortDirection = 'desc'
        }else if($(e).hasClass('column-sorted-desc')){
            $(e).removeClass('column-sorted-desc')
            $(e).addClass('column-sorted')
            sortConfig.SortDirection = 'asc'
        }else {
            $(e).addClass('column-sorted')
            sortConfig.SortDirection = 'asc'
        }
        $(e).children().remove('.column-no-sort-indicator')
        $(e).append('<span class="column-sort-indicator"></span>')
        
        sortConfig.SortField = $(e).attr('sort-column')

        transactionModule.getTransactions(currentPage, sortConfig)
    }

    return {
        fillPages: fillPages,
        selectPage: selectPage,
        sort: sort
    }
})()
